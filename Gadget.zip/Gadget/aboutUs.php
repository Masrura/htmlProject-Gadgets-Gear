<!DOCTYPE html>
<html>
	<head>
		<title> ABOUT US</title>
		<link rel="stylesheet" href="css/style_aboutUs.css">
		<meta charset="UTF-8">
		<meta name="keywords" content="gadgets,smartphone,review">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">

	</head>
	<body>
		<header>Gadgets And Gear</header>
			<ul class="a">
				<li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=android"> SMARTPHONE </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
							
		 	</ul>
		 	<div class="about">
		 		<h2><p>ABOUT US :</p></h2><br><h3>WELCOME TO GADGETS NOW</h3><br>
		 		<h4>Gadgets Now is the technology destination of the globe's most-read website.The Times of India. We cover everything and anything <br>technology, news, views, reviews, launches, trends and much more.</h4>
		 		<h4><p>With our roots in the country’s biggest media powerhouse, The Times of India group, news is one of our biggest strengths. You can <br> read about all that happens just anywhere in the world of technology, including gadgets and gizmos, on Gadgets Now.</p></h4>
		 		<h4><p>Gadgets Now is also the go-to destination for gadget reviews. Here you will find in-depth reviews of smartphones, cameras, TVs, speakers,<br> laptops, smartwatches, tablets, fitness bands, power banks and more</p></h4>
		 		<h4><p>How-tos are another forte of Team Gadgets Now. How to post multiple photos on Instagram, how to set up Wi-Fi router in your home, <br>step-by-step guide to make the switch from Android smartphone to iPhone and vice-versa,<br> how to turn your Windows 10 PC into a kiosk, how to post 360-degree photos on Facebook and lots more.</p></h4>
		 		<h4><p>Prefer watching a video to reading? Our video section has you covered. It has everything you could possibly need to stay <br> updated — unboxing videos, reviews, how-to videos and videos on all that’s buzzing and trending in the tech landscape.</p></h4>
		 		<h3><p>We do appreciate your feedback</p></h3><br>
		 		<h4>We will be glad to hear from you if:
					- You have found a mistake in our phone specifications.
					- You have info about a phone which we don't have in our <br> database.
					- You have found a broken link.
					- You have a suggestion for improving Gadgets & Gear or you want to request a feature.  </h4>
				


          <footer>
         <div class="icon">
           <div class="fa fa-facebook"></div>
           <div class="fa fa-twitter"></div>
            <div class="fa fa-instagram"></div>

       </div>
        Copyright Property of Aust Buddy
    </footer>
		 	</div>
	</body>
</html>	

<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";

header
{
	
	border: 2px solid gray;
	background-color: #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}


ul.a
{
	list-style: none;
	

}
ul.a li
{
	float: left;
	padding-right: 100px;
  

}
ul.a li a
{
	text-decoration: none;
	padding: 10px;
	font-family: algerian;
	color: white;
    border: none;
	color: #044204;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

}

h2
{
	position: relative;
	top: 50px;
	left: -1100px;
}

ul.a li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
ul.a li a:hover:before
{
	width: 100%;
}

body
{
	background-color: #c3bcb7;
	font-family: algerian;
	color: white;

}

div.about
{
	background-color:#35424a;
	position: relative;
	top: 50px;
	padding-right: 5px;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

h3
{
	position: relative;
	left: 100px;
	color: rgb(169, 202, 216);
}

footer
{
	border: 2px solid gray;
	background-color: #35424a;
	font-size:15px;
	text-align: center;
 	font-family: algerian;
 	color: white;
 	position: relative;
 	bottom: -50px;
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

.icon {
    right: 10%;
    top: 20%;
}

.icon > div {
        margin: 0px, 10px;
        width: 40px;
        height: 40px;
        background: #eee;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        color: white;
        transition: all 300ms ease-in-out;
    }

div.fa-facebook {
    background: #5252b8;
}

div.fa-twitter {
    background: #00acee;
}

div.fa-instagram {
    background-color: palevioletred;
}

div.fa-facebook:hover {
    color: #5252b8;
    background-color: white;
    border: 1px solid #5252b8;
}

div.fa-twitter:hover {
    color: #00acee;
    background-color: white;
    border: 1px solid #00acee;
}

div.fa-instagram:hover {
    color: palevioletred;
    background-color: white;
    border: 1px solid #00acee;
}

</style>	