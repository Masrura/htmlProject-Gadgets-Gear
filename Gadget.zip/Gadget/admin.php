<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "gadgets");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
    $brand=$_POST['brand'];
    $model=$_POST['model'];
    $camera=$_POST['camera'];
    $battery=$_POST['battery'];
    $price=$_POST['price'];
    $display=$_POST['display'];
    $storage=$_POST['storage'];
    $color=$_POST['color'];
    $os=$_POST['os'];
  	// image file directory
  	$target = "img/".basename($image);

  	$sql = "INSERT INTO phones (model,brand,image,price,battery,camera,display,colors,storage,os) VALUES ('$model','$brand','$image','$price','$battery','$camera','$display','$storage','$color','$os')";
  	// execute query
  	$result=mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Failed to upload image";
      ?>
      <script>alert('Successful.')</script>
      <?php
  	}
    else{
  		$msg = "Failed to upload image";
      ?>
      <script>alert('unSuccessful.')</script>
      <?php
  	}
  }
  
?>


<!DOCTYPE html>
<html>
	<head>
		<title>Gadgets & Gear</title>
		<meta charset="UTF-8">
		<meta name="keywords" content="gadgets,smartphone,review">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
			<header>
				GADGETS AND GEAR
			</header>

			<button id="btnInsert" class="btn btn-danger" type="button" data-toggle="modal" data-target="#insertModal">Insert Product</button>

			<div id="insertModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" id="insertContent">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Insert Product</h4>
      </div>
      <div class="modal-body" id="insertMod">
        

<div id="content">
  <form id="insertBox" method="POST" action="admin.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div id="box">
      <h2><strong>Insert Image Here</strong></h2>
  	  <input type="file" name="image">
      <br>
      <input placeholder="brand" type="text" name="brand">
    
          <input placeholder="model" type="text" name="model">    
      
          <input placeholder="camera" type="text" name="camera">
     
          <input placeholder="battery" type="text" name="battery">
    
          <input placeholder="price" type="text" name="price">
    
          <input placeholder="display" type="text" name="display">
    
          <input placeholder="color" type="text" name="color">

          <input placeholder="os" type="text" name="os">
    
          <input placeholder="storage" type="text" name="storage">


  	</div>
  	<div>

  	</div>
  	<div>
  		<button class="btn btn-danger" id="post" type="submit" name="upload">POST</button>
  	</div>
  </form>
</div>
               

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</div>



<!--<div id="upNdel">-->
<a href="upNdel.php"><button id="btnUpdel" class="btn btn-danger" type="button">See Product</button></a>
</br>
<a href="ordertable.php"><button id="btnOrder" class="btn btn-danger" type="button">See Order Table</button></a>


    

    <footer>
				<h2>Copyright Property of Gadgets and Gear</h2>
			</footer>
		</div>	
</body>

</html>

<style type="text/css">






th {
  color: #000000;
  background-color: #d82525;
  height: 35px;

}

td {
  text-align: center;
  column-width: 50px;
  color: #000000;
}

#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

  #customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
  }

  #customers tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  #customers tr:hover {
    background-color: #ddd;
  }

  #customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
  }



#name
{
  display: inline-block;
}

#enter
{
  float: right;
  margin-right: 190px;
  width: 80px;
  height: 32px;
}

#del
{
  height:30px;
}

#insertContent {

  background-image: url(img/nextbg.png);
}


#insertMod form {

    background-image: url(img/nextbg.png);
}


#btnInsert
{
  margin-left: 17%;
  margin-top: 7%;
  height: 150px;
    width: 29%;
    font-size: 30px;
    border: 3px solid rgb(213,0,0);
}

#btnInsert:hover {
 border: 3px dotted rgb(213,0,0);
  color: rgb(213,0,0);
  background: rgba(0,0,0,0);
}

#btnUpdel
{
  margin-left: 57%;
  margin-top: -13%;
  height: 150px;
    width: 29%;
    font-size: 30px;
     border: 3px solid rgb(213,0,0);
}

#btnUpdel:hover {
 border: 3px dotted rgb(213,0,0);
  color: rgb(213,0,0);
  background: rgba(0,0,0,0);
}

#btnOrder
{
  margin-left: 35%;
  margin-top: 2%;
   height: 150px;
    width: 29%;
    font-size: 30px;
    border: 3px solid rgb(213,0,0);
}

#btnOrder:hover
 {
 border: 3px dotted rgb(213,0,0);
  color: rgb(213,0,0);
  background: rgba(0,0,0,0);
}


h2{

  color: #ff3333;
  font-size: 15px;
  margin-left: -140px;


}

#post
{
   margin-left: -4%;
   margin-top: 10%;
   height: 32px;
   width: 70px;
   border: 3px solid rgb(213,0,0);
}
#post:hover
 {
 border: 3px dotted rgb(213,0,0);
  color: rgb(213,0,0);
  background: rgba(0,0,0,0);
}
#insertBox
{
   position: relative;
  text-align: center;
  margin: 5% auto;
  width: 325px;
  height: 620px;
  background: #FFF;
  border-radius: 2px;
  box-shadow: 0 0px 4px rgba(0, 0, 0, 0.4);
  background-image: url(img/nextbg.png);
}

#box
{
  margin-left: 16%;
}


input[type="text"]
 {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
}

input[type="text"]:focus
{
  border-bottom: 2px solid #16a085;
  color: #16a085;
  transition: 0.2s ease;
}



header
{
	
	border: 2px white;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: white;
 	padding: 1em;
 	background-color: #35424a;
 	border-bottom: black 3px solid;
   -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
footer
{
	border: 2px solid gray;
	background-color: black;
	font-size:10px;
	text-align:center;
 	font-family: normal;
 	line-height: 480%;
 	color: rgb(255,255,255);
 	height: 80px;
 	margin-top: 45%;
 	

}

</style>