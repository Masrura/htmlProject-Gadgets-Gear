<?php
include 'config.php';

 

?>

<!DOCTYPE html>
<html>
<head>
	<title> Details</title>
	<link rel="stylesheet" href="css/style_details.css">
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>-->
	<meta charset="UTF-8">
	<meta name="keywords" content="gadgets,smartphone,review">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

</head>
<body>
<div class="whole">
		<header>cart</header>
		 <ul class="a">
		            <li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=android"> SMARTPHONE </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
						
		</ul>
		<nav>
			<ul class="nav">
				<li><a href="samsung.php?name=nokia"> NOKIA </a></li>
		    	<li><a href="samsung.php?name=samsung"> SAMSUNG </a></li>
		    	<li><a href="samsung.php?name=sony"> SONY </a></li>
		    	<li><a href="samsung.php?name=huawei"> HUAWEI </a></li>
		    	<li><a href="samsung.php?name=xiaomi"> XIAOMI </a></li> </li>
				<li><a href="samsung.php?name=walton"> WALTON </a> </li>
		    	<li><a href="samsung.php?name=htc"> HTC </a> </li>
		        <li><a href="samsung.php?name=oppo"> OPPO </a> </li></td>
		    	<li><a href="samsung.php?name=symphony"> SYMPHONY </a></li>
		    	<li><a href="samsung.php?name=asus"> ASUS </a></li>
						
			</ul>
		</nav>


<div class="range">
			<ul>
				<li>Smartphone Price Range:</li>
					<ul>
						<li><a href="samsung.php?range=0 & range2=5000">0-5000</a></li>
						<li><a href="samsung.php?range=5000 & range2=10000">5000-10000</a></li>
						<li><a href="samsung.php?range=10000 & range2=20000">10000-20000</a></li>
						<li><a href="samsung.php?range=30000 & range2=40000">30000-40000</a></li>
						<li><a href="samsung.php?range=50000 & range2=60000">50000-60000</a></li>
						<li><a href="samsung.php?range=60000 & range2=90000">60000+</a></li>
			</ul>		</ul>
		</div>
			<div class="topb">
				<li>Top Brands :</li>
					<ul class="range">
						<li><a href="samsung.php?name=samsung">Samsung</a></li>
						<li><a href="samsung.php?name=walton">Walton</a></li>
						<li><a href="samsung.php?name=htc">HTC</a></li>
						<li><a href="samsung.php?name=sony">Sony</a></li>
						<li><a href="samsung.php?name=nokia">Nokia</a></li>
						<li><a href="samsung.php?name=huawei">Huawei</a></li>
				    </ul>
			</div>
			
             
             <form method="POST" action="#">
             	<div class="cartInfo">

			
			<input type="text" name="quantity" placeholder="Quantity">			
			<input type="text" name="addr" placeholder="Address">
			<input type="submit" name="addToMyCart" value="Add To My Cart">
				
			</div>
             </form>
			


        <?php

      

 if (isset($_POST["addToMyCart"])) 
        {
        		
                
                $quan = $_POST['quantity'];
                $add= $_POST['addr'];
                 
               session_start();

                 $sql1 = $_SESSION['sess_pid'];
               
                $sql2 =$_SESSION['sess_cid'];
                $pro_price = $_SESSION['sess_price'];
               //$sql1 = "SELECT id FROM phones WHERE model = '{$_SESSION['sess_id']}'";
               
	           /* $result1 = mysqli_query($conn, $sql1);

	              $sql2 = "SELECT customerId FROM registration WHERE phoneNumber= '{$_SESSION['sess_cid']}'";
		       // $sql2 = $_SESSION['sess_cid'];
	            $result2 = mysqli_query($conn, $sql2);


                if(mysqli_num_rows($result1)>0)
                {
                  while ($row = mysqli_fetch_array($result1))
					{
						$productId=$row['id'];
                        //$product = $productId;
                        ?>
               

                        <?php

		            }
                 }*/
		            
               
		        //$sql2 = "SELECT customerId FROM registration WHERE phoneNumber= '{$_SESSION['sess_cid']}'";
		       // $sql2 = $_SESSION['sess_cid'];
		        //echo ($sql2);
	            //$result2 = mysqli_query($conn, $sql2);

                /*if(mysqli_num_rows($result2)>0)
                {
                  while ($row = mysqli_fetch_array($result2))
					{
						$customer=$row['customerId'];
                        //$cust = $customer;
                         echo ($customer);
		            }
		        }*/

               $conn=new mysqli('localhost' ,'root' ,'') or die(mysqli_error());
           $db=mysqli_select_db($conn,'gadgets') or die("DB Error");
		      $sql="INSERT INTO cart (c_id,p_id,quantity,address,price) VALUES ('$sql2','$sql1','$quan','$add', '$pro_price')";
              $result=mysqli_query($conn,$sql);

              if($result)
              {
                ?>
                  <script>alert('Added to Cart')</script>
                    <?php

                     $_SESSION['sess_pid'] = $sql1;
                   $_SESSION['sess_cid'] = $sql2;
                    $_SESSION['sess_price'] = $pro_price;
                   header("Location:seeMyCart.php");
                   exit();
              }

              else 
              {
                 ?>
                  <script>alert('unsuccessfull')</script>
                    <?php
              }
        	
        }
        ?>
               
     </div>

</body>
</html>
<?php
include 'close.php';
?>

<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";
body
{
	background-color: #c3bcb7;
	font-family: algerian;
	color: white;

}

header
{
	
	
	background-color:  #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
nav 
{
	border-style: none;
	margin-top: 30px;
	
}
nav ul
{
	list-style: none;
	margin-right: 20px;
	float: left;
	margin-left: 10px;
	border-style: double;
	border-bottom: #e8491d 3px solid;
	background-color:  #35424a;
	border-color: #e8491d;
	margin-top: 5%;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
nav ul li
{
	margin:15px;

}
nav ul li a
{
	text-decoration: none;
	padding: 15px;
	font-family: algerian;
	color: white;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease;


}

nav ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
nav ul li a:hover:before
{
	width:100%;
}
ul.a
{
	list-style: none;
	

}
ul.a li
{
	float: left;
	padding-right: 100px;
  

}
ul.a li a
{
	text-decoration: none;
	padding: 10px;
	font-family: algerian;
	color: white;
    border: none;
	color: #044204;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

}

ul.a li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
ul.a li a:hover:before
{
	width: 100%;
}
div.range
{
	float: right;
	margin: 10px;
	border-style: double;
	border-color: #e8491d;
	background-color: #35424a;
	position: relative;
	padding: 06px;
 	border-bottom: #e8491d 3px solid;
 	top: 10%;
 	margin-top: 6%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
div.range ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	color: rgba(248, 251, 245, 0.91);
	font-size: 100%;
}

}
div.range ul li
{
	padding: 5px;

}
div.range ul li a
{
	text-decoration: none;
	padding: 5px;
	text-align: center;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 
}

div.range ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
} 
div.range ul li a:hover:before {
	
	width: 100%
}
div.topb
{
	float: right;
	margin: 10px;
	border-style: double;
	position: relative;
	top:520px;
	left: 280px;
	right: 10px;
	padding: 45px;
	background-color: #35424a;
	border-color: #e8491d;
 	border-bottom: #e8491d 3px solid;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
div.topb ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	

}
div.topb  li
{
	padding: 3px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	color:rgb(233, 241, 225);
	font-size: 131%;
}
div.topb ul li a
{
	text-align: center;
	text-decoration: none;
	padding: 5px;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

	
}

div.topb ul li a:before
{
   content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
div.topb ul li a:hover:before
{
	
    width: 100%;
}
div.about
{
	float: right;
	margin: 20px;
	border-style: inset;
	position: relative;
	top:820px;
	left: 560px;
	right: 10px;
	padding: 40px;
	background-color:  #35424a;
	
}
div.about ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	
}
div.about  li
{
	padding: 10px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	
}
div.about ul li a
{
	text-decoration: none;
	padding: 5px;
	color: white;
	
}
div.about ul li a:hover
{
	background-color:rgb(78,155,0);
}

.cartInfo
{
       background: white;
    border: 3px solid rgba(0, 100, 158, 0.96);
    border-radius: 6px;
    height: 284px;
    margin: 20px auto 0;
    width: 298px;
    margin-top: 9%;
    text-align: center;
    color: rgba(43, 130, 121, 0.74);
    font-size: 24px;
}

input[type="text"]
{
   
      border: 1px solid #2b8279;
    border-radius: 4px;
    box-shadow: 0 1px #fff;
    box-sizing: border-box;
    color: #696969;
    height: 39px;
    margin: 27px -25px 3px 11px;
    padding-left: 36px;
    transition: box-shadow 0.3s;
    width: 240px;
    margin-top: 45px;
}

input[type="text"]:focus {
  box-shadow: 0 0 4px 1px rgba(55, 166, 155, 0.3);
  outline: 0;
}

input[type="submit"]
{
  width:240px;
  height:35px;
  display:block;
  font-family:Arial, "Helvetica", sans-serif;
  font-size:16px;
  font-weight:bold;
  color:#fff;
  text-decoration:none;
  text-transform:uppercase;
  text-align:center;
  text-shadow:1px 1px 0px #37a69b;
  padding-top:6px;
  margin: 29px 0 0 29px;
  position:relative;
  cursor:pointer;
  border: none;  
  background-color: #37a69b;
  background-image: linear-gradient(top,#3db0a6,#3111);
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
  border-bottom-left-radius:5px;
  box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #497a78, 0px 10px 5px #999;

}
    
.shadow {
  background: #000;
  border-radius: 12px 12px 4px 4px;
  box-shadow: 0 0 20px 10px #000;
  height: 12px;
  margin: 30px auto;
  opacity: 0.2;
  width: 270px;
}


input[type="submit"]:active {
  top:3px;
  box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #31524d, 0px 5px 3px #999;
}


</style>