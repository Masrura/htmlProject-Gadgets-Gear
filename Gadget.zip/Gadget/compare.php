<?php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
	<title>Compare</title>
	<link rel="stylesheet" href="css/style_login.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
				
</head>
<body>

<form action="" id="compareForm" method="post">

<br>
<select name="phone1List" form="compareForm" >
	  <?php
        $query = "SELECT model FROM phones ";
        $phone_query_result = mysqli_query($conn,$query) or die(mysql_error());

        if(mysqli_num_rows($phone_query_result)>0)
        {
          while ($row = mysqli_fetch_array($phone_query_result))
          {
      ?>
                <option value="<?php echo $row['model']; ?>"><?php echo $row['model']; ?></option>
               
        <?php
          }
        }
        ?>
  
  
</select>

<select name="phone2List" form="compareForm">
  <?php
        $query = "SELECT model FROM phones ";
        $phone_query_result = mysqli_query($conn,$query) or die(mysql_error());

        if(mysqli_num_rows($phone_query_result)>0)
        {
          while ($row = mysqli_fetch_array($phone_query_result))
          {
          	?>
                <option value="<?php echo $row['model']; ?>"><?php echo $row['model']; ?></option>
                <?php
                //$phone1=$_POST['phone1List'];
                //$phone1="habijabi";
                //$phone2=$_POST["phone2List"];
          }
        }
        ?>
  
 
</select>
</br>
<input type="submit" name="compare" value="Compare">
</form>
<!--<li><a href="cmp.php?name=<?php echo $_POST['phone1List']; ?>">Compare</a></li>-->

<?php
if(isset($_POST['compare']))
{
  $phone1=$_POST['phone1List'];
  $phone2=$_POST['phone2List'];

  //echo $phone1;
  //echo $phone2;
?>
  <div class="details">
         <?php
        $query = "SELECT * FROM phones WHERE model = '" .$phone1."'";
        $query2 = "SELECT * FROM phones WHERE model = '" .$phone2."'";
        $phone_query_result = mysqli_query($conn,$query) or die(mysql_error());
        $phone_query_result2 = mysqli_query($conn,$query2) or die(mysql_error());
        $row2=mysqli_fetch_array($phone_query_result2) ;

        if(mysqli_num_rows($phone_query_result)>0  )
        {
          while ($row = mysqli_fetch_array($phone_query_result) )
          {
            $id=$row['id'];
          
        ?>

        
          <img class="pic1" src="<?php echo $row['image'];?>">
         <img class="pic2" src="<?php echo $row2['image'];?>">
         
           

        <table>
            <tr>
              <td class="columnEx"><li> <?php echo $row['model'];?><br> <?php echo $row['price'];?> </li></td>
              <td class="columnEx"><li> <?php echo $row2['model'];?><br> <?php echo $row2['price'];?> </li></td>

          <tr>
            <td class="column1"><li> Network Scope </li></td>
                <td class="column2"><li> <?php echo $row['network'];?></li></td>
                <td class="column2"><li> <?php echo $row2['network'];?></li></td>

          </tr>
          <tr>
            <td class="column1"><li> Battery Type & Performance </li></td>
                <td class="column2"><li> <?php echo $row['battery'];?></li></td>
                <td class="column2"><li> <?php echo $row2['battery'];?></li></td>
          </tr>
          <tr>
                <td class="column1"><li> Camera</li></td>
                <td class="column2"><li><?php echo $row['camera'];?></li></td>
                 <td class="column2"><li><?php echo $row2['camera'];?></li></td>
          </tr>
          
          <tr>
            <td class="column1"><li> Colors Available </li></td>
                <td class="column2"><li><?php echo $row['colors'];?></li></td>
                <td class="column2"><li><?php echo $row2['colors'];?></li></td>
          </tr>
          <tr>
            <td class="column1"><li> Display Size & Resolution </li></td>
                <td class="column2"><li> <?php echo $row['display'];?> </li></td>
                <td class="column2"><li> <?php echo $row2['display'];?> </li></td>
          </tr>
          <tr>
            <td class="column1"><li> Operating System </li></td>
                <td class="column2"><li> <?php echo $row['os'];?></li></td>
                <td class="column2"><li> <?php echo $row2['os'];?></li></td>
          </tr>
          <tr>
            <td class="column1"><li> Processor </li></td>
                <td class="column2"><li><?php echo $row['processor'];?></li></td>
                 <td class="column2"><li><?php echo $row2['processor'];?></li></td>

          </tr>
          <tr>
            <td class="column1"><li> RAM & ROM</li></td>
                <td class="column2"><li> <?php echo $row['storage'];?> </li></td>
                <td class="column2"><li> <?php echo $row2['storage'];?> </li></td>
          </tr>
          
          <tr>
            <td class="column1"><li> Special Features </li></td>
                <td class="column2"><li><?php echo $row['special_feature'];?> </li></td>
                <td class="column2"><li><?php echo $row2['special_feature'];?> </li></td>
          </tr>
          <tr>
            <td class="column1"><li> Other Features</li></td>
                <td class="column2"><li><?php echo $row['other_feature'];?></li></td>
                <td class="column2"><li><?php echo $row2['other_feature'];?></li></td>
          </tr>

      <?php
    }
  }
  ?>
        </table>
      </div>  

  
<?php 
}

?>
<?php

/*if(isset($_POST["compare"]))
{

	//$phone1=$_POST["phone1List"];
	//$phone2=$_POST["phone2List"];
	session_start();
	header("Location:login.php");
	exit();
?>
<!--<label>iduhfiufhv</label>-->
<?php
}
?>
*/
?>
</body>
</html>

<?php
include 'close.php';
?>

<style type="text/css">

body
{
  background-color:rgba(246, 239, 239, 0.93);
}
img.pic1
{
  float: left;
  position: relative;
  left:200px;
  top: 10px;
}
img.pic2
{
  float: left;
    position: relative;
    left: 500px;
    top: -60px;
}
table
{
  
  left:200px;
  margin-top: 5%;
  width: 700px;
  color: white;
  -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
table tr li
{
  list-style: none;

}
div.details
{
  margin-top: 100px;
}
img.pic1
{
  float: left;
    position: relative;
    left: 470px;
    top: -60px;

  
}

table
{
  position:relative;
  left:-90px;
  top: 295px;
  width: 700px;

}
table tr li
{
  list-style: none;

}
div.pName
{
  text-align: center;
  position: relative;
  top: 300px;
  left: 50px;
}
 .column1
{
  text-decoration: none;
  border-style: groove;
  text-align: center;
  height: 50px;
  font-size: 15px;
   font-family: Franklin Gothic Heavy;
  top: 100%;
  padding: 10px;
  background-color:#737A73;
  -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
.column2
{
  height: 50px;
  width: 1000px;
  text-decoration: none;
  border-style: groove;
  text-align: center;
  font-size: 15px;
  padding: 5px; 
  font-family: Franklin Gothic Heavy;
  background-color:#737A73  ;
  -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
.columnEx
{
     padding: 10px;
    width: 400px;
    position: relative;
    top: -120px;
    left: 280px;
    color:rgb(0,0,0);
}

#compareForm
{
  margin-left: 33%;
    margin-top: 3%;
}

input[type="submit"]
{
   margin-top: 5%;
    margin-left: 15%;
    display: inline-block;
    vertical-align: middle;
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    transition-duration: 0.3s;
    transition-property: transform;
    background-color:rgba(232, 137, 105, 0.99);
    border-radius: 8px;
  height: 37px;
  width: 100px;
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  color: white;
  font-size: 20px;

}

input[type="submit"]:hover,
input[type="submit"]:focus,
input[type="submit"]:active {
    transform: scale(1.3);
}


</style>