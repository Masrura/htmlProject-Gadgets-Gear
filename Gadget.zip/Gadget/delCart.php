<!--<?php
	//include_once('config.php');
 
	//if( isset($_GET['delete']) )
	{
		//$id = $_GET['delete'];
		//$sql= "DELETE FROM cart WHERE p_id ='$id'";
		//$res= mysqli_query($conn,$sql) or die("Failed".mysql_error());
		//echo "<meta http-equiv='refresh' content='0;url=seeMyCart.php'>";
	}
?>-->

<?php

	$link = mysqli_connect("localhost", "root", "", "gadgets");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt update query execution
if (isset($_GET['delete'])) 
{
	$id = $_GET['delete'];
	$sql = "DELETE FROM cart WHERE p_id ='$id'";
if(mysqli_query($link, $sql)){
    //echo "Records were updated successfully.";
    echo "<meta http-equiv='refresh' content='0;url=seeMyCart.php'>";
} 
else {
   // echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

	?>
	 <script>alert('This Products are already Confirmed.You cannot delete it')</script>
	 <?php
     echo "<meta http-equiv='refresh' content='0;url=seeMyCart.php'>";
}
}

 
// Close connection
mysqli_close($link);
?>