<?php
	include_once('config.php');
 
	if( isset($_GET['del']) )
	{
		$id = $_GET['del'];
		$sql= "DELETE FROM phones WHERE id='$id'";
		//$res= mysqli_query($conn,$sql);
	}

	if(mysqli_query($conn,$sql))
	{

		echo "<meta http-equiv='refresh' content='0;url=upNdel.php'>";
	}
	else
	{
		?>
	 <script>alert('This Product is pending for delivery to Customers.You cannot delete it now')</script>
	 <?php
	 echo "<meta http-equiv='refresh' content='0;url=upNdel.php'>";

	}
	

	if( isset($_GET['edit']) )
	{
		$id = $_GET['edit'];
		$price=$_GET['price'];
		$sql= "UPDATE FROM phones SET price='$price' WHERE id='$id'";
		$res= mysqli_query($conn,$sql) or die("Failed".mysql_error());
		echo "<meta http-equiv='refresh' content='0;url=upNdel.php'>";
	}
?>