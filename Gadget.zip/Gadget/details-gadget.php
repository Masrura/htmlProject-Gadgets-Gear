<?php
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title> Details</title>
	<link rel="stylesheet" href="css/style_details.css">
	<meta charset="UTF-8">
	<meta name="keywords" content="gadgets,smartphone,review">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

</head>
<body>
	<div class="whole">
		<header><?php echo $_GET['name'] ;?></header>
		 <ul class="a">
			<li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=android"> SMARTPHONE </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
						
		</ul>
		<nav>
			<ul class="nav">
				<li><a href="samsung.php?name=nokia"> NOKIA </a></li>
		    	<li><a href="samsung.php?name=samsung"> SAMSUNG </a></li>
		    	<li><a href="samsung.php?name=sony"> SONY </a></li>
		    	<li><a href="samsung.php?name=huawei"> HUAWEI </a></li>
		    	<li><a href="samsung.php?name=xiaomi"> XIAOMI </a></li> </li>
				<li><a href="samsung.php?name=walton"> WALTON </a> </li>
		    	<li><a href="samsung.php?name=htc"> HTC </a> </li>
		        <li><a href="samsung.php?name=oppo"> OPPO </a> </li></td>
		    	<li><a href="samsung.php?name=symphony"> SYMPHONY </a></li>
		    	<li><a href="samsung.php?name=asus"> ASUS </a></li>
						
			</ul>
		</nav>
		<div class="range">
			<ul>
				<li>Smartphone Price Range:</li>
					<ul>
							<li><a href="samsung.php?range=0 & range2=5000">0-5000</a></li>
						<li><a href="samsung.php?range=5000 & range2=10000">5000-10000</a></li>
						<li><a href="samsung.php?range=10000 & range2=20000">10000-20000</a></li>
						<li><a href="samsung.php?range=30000 & range2=40000">30000-40000</a></li>
						<li><a href="samsung.php?range=50000 & range2=60000">50000-60000</a></li>
						<li><a href="samsung.php?range=60000 & range2=90000">60000+</a></li>
			</ul>		</ul>
		</div>
			<div class="topb">
				<li>Top Brands :</li>
					<ul class="range">
						<li><a href="samsung.php?phone=samsung">Samsung</a></li>
						<li><a href="samsung.php?phone=walton">Walton</a></li>
						<li><a href="samsung.php?phone=htc">HTC</a></li>
						<li><a href="samsung.php?phone=sony">Sony</a></li>
						<li><a href="samsung.php?phone=nokia">Nokia</a></li>
						<li><a href="samsung.php?phone=huawei">Huawei</a></li>
				    </ul>
			</div>
			<div class="about">	
				<li>Contact :</li>
					<ul>
						<li><a href="">Facebook</a></li>
						<li><a href="">Twitter</a></li>
						<li><a href="">Instagram</a></li>
					</ul>
			</div>
			<div class="details">
				 <?php
				$query = "SELECT * FROM gadget WHERE gadget_name = '" . $_GET['name'] . "'";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result)>0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
					
				?>

				
			    <img class="pic2" src="<?php echo $row['image'];?>">
			 
			     

				<table>
				    <tr>
				    	<td class="columnEx"><li> <?php echo $row['gadget_name'];?><br> <?php echo "Price"; echo $row['price'];?> </li></td>
				    </tr>	

					<tr>
						<td class="column1"><li> Feature </li></td>
			    	    <td class="column2"><li> <?php echo $row['feature'];?></li></td>

				   </tr>
				

			<?php
		}
	}
	?>
				</table>
			</div>		

		</div>

</body>
</html>
<?php
include 'close.php';
?>
<style type="text/css">body
{
	background-color: rgb(102,0,51);
	font-family: algerian;
	color: white;

}
header
{
	
	border: 2px solid gray;
	background-color:  #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;

}
nav 
{
	margin-top: 60px;
	border-style: inset;
	position: relative;


}
nav ul
{
	list-style: none;
	margin-right: 20px;
	float: left;
	border-style: outset;
	background-color:  #35424a;
}
nav ul li
{
	margin:15px;
	background-color:  #35424a;
}
nav ul li a
{
	text-decoration: none;
	padding: 15px;
	font-family: algerian;
	color: white;

}
nav ul li a:hover 
{
	background-color:rgb(78,155,0);
}
ul.a
{
	list-style: none;
	border-color: black;

	
}
ul.a li
{
	float: left;
	padding-right: 100px;

}
ul.a li a
{
	text-decoration: none;
	padding: 10px;
	font-family: algerian;
	color: white;


}
ul.a li a:hover
{
	background-color:rgb(78,155,0);
}
div.range
{
	float: right;
	margin: 20px;
	border-style: inset;
	position: relative;
	padding: 06px;
	background-color:  #35424a;
	color: white;

}
div.range ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
}
div.range ul li
{
	padding: 5px;
	list-style: none;

}
div.range ul li a
{
	text-decoration: none;
	padding: 5px;
	color: white;
}
div.range ul li a:hover
{
	background-color:rgb(78,155,0);

}
div.topb
{
	float: right;
	margin: 20px;
	border-style: inset;
	position: relative;
	top:350px;
	left: 280px;
	right: 10px;
	padding: 45px;
	background-color:  #35424a;
	color: white;
}
div.topb ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	list-style: none;
}
div.topb  li
{
	padding: 10px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
}
div.topb ul li a
{
	text-decoration: none;
	padding: 5px;
	color: white;
	
}
div.topb ul li a:hover
{
	background-color:rgb(78,155,0);

}
div.about
{
	float: right;
	margin: 20px;
	border-style: inset;
	position: relative;
	top:820px;
	left: 560px;
	right: 10px;
	padding: 40px;
	background-color:  #35424a;
	
}
div.about ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	
}
div.about  li
{
	padding: 10px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	
}
div.about ul li a
{
	text-decoration: none;
	padding: 5px;
	color: white;
	
}
div.about ul li a:hover
{
	background-color:rgb(78,155,0);
}
div.details
{
	margin-top: 30px;
}
img.pic1
{
	float: left;
	position: relative;
	
	
}
img.pic2
{
	float: left;
	position: relative;
	left: 280px;
	top:-270px;
	
}
img.pic3
{
	float: left;
	position: relative;
	left: 400px;
	top:-300px;
	
}
table
{
	position:relative;
	left:-350px;
	top: 100px;
	

}
table tr li
{
	list-style: none;
}
div.pName
{
	text-align: center;
	position: relative;
	top: 300px;
	left: 50px;
}
 .column1
{
	text-decoration: none;
	border-style: groove;
	text-align: center;
	height: 50px;
	font-size: 15px;
	padding: 5px;
	background-color:#737A73  ;
}
.column2
{
	height: 50px;
	text-decoration: none;
	border-style: groove;
	text-align: center;
	font-size: 15px;
	padding: 5px; 
	font-family: Franklin Gothic Heavy;
	background-color:#737A73  ;
}
.columnEx
{
	padding: 10px;
	width: 400px;
	position: relative;
	top: 0px;
	left: 180px;
}</style>