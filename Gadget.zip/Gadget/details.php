<?php
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title> Details</title>
	<link rel="stylesheet" href="css/style_details.css">
	<meta charset="UTF-8">
	<meta name="keywords" content="gadgets,smartphone,review">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

</head>
<body>
	<div class="whole">
		<header><?php echo $_GET['name'] ;?></header>
		 <ul class="a">
		<li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=android"> SMARTPHONE </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
						
		</ul>
		<nav>
			<ul class="nav">
				<li><a href="samsung.php?name=nokia"> NOKIA </a></li>
		    	<li><a href="samsung.php?name=samsung"> SAMSUNG </a></li>
		    	<li><a href="samsung.php?name=sony"> SONY </a></li>
		    	<li><a href="samsung.php?name=huawei"> HUAWEI </a></li>
		    	<li><a href="samsung.php?name=xiaomi"> XIAOMI </a></li> </li>
				<li><a href="samsung.php?name=walton"> WALTON </a> </li>
		    	<li><a href="samsung.php?name=htc"> HTC </a> </li>
		        <li><a href="samsung.php?name=oppo"> OPPO </a> </li></td>
		    	<li><a href="samsung.php?name=symphony"> SYMPHONY </a></li>
		    	<li><a href="samsung.php?name=asus"> ASUS </a></li>
						
			</ul>
		</nav>
		<div class="range">
			<ul>
				<li>Smartphone Price Range:</li>
					<ul>
						<li><a href="samsung.php?range=0 & range2=5000">0-5000</a></li>
						<li><a href="samsung.php?range=5000 & range2=10000">5000-10000</a></li>
						<li><a href="samsung.php?range=10000 & range2=20000">10000-20000</a></li>
						<li><a href="samsung.php?range=30000 & range2=40000">30000-40000</a></li>
						<li><a href="samsung.php?range=50000 & range2=60000">50000-60000</a></li>
						<li><a href="samsung.php?range=60000 & range2=90000">60000+</a></li>
			</ul>		</ul>
		</div>
			<div class="topb">
				<li>Top Brands :</li>
					<ul class="range">
						<li><a href="samsung.php?name=samsung">Samsung</a></li>
						<li><a href="samsung.php?name=walton">Walton</a></li>
						<li><a href="samsung.php?name=htc">HTC</a></li>
						<li><a href="samsung.php?name=sony">Sony</a></li>
						<li><a href="samsung.php?name=nokia">Nokia</a></li>
						<li><a href="samsung.php?name=huawei">Huawei</a></li>
				    </ul>
			</div>
			
			<div class="details">
				 <?php
				$query = "SELECT * FROM phones WHERE model = '" . $_GET['name'] . "'";
				$phone_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($phone_query_result)>0)
				{
					while ($row = mysqli_fetch_array($phone_query_result))
					{
						$id=$row['id'];
						$price = $row['price'];
					
				?>

				
			    <img class="pic1" src="<?php echo $row['image'];?>">
			   
			     

				<table>
				    <tr>
				    	<td class="columnEx"><li> <?php echo $row['model'];?><br> <?php echo $row['price'];?> </li></td>

					<tr>
						<td class="column1"><li> Network Scope </li></td>
			    	    <td class="column2"><li> <?php echo $row['network'];?></li></td>

					</tr>
					<tr>
						<td class="column1"><li> Battery Type & Performance </li></td>
			    	    <td class="column2"><li> <?php echo $row['battery'];?></li></td>
					</tr>
					<tr>
						<td class="column1"><li> Camera</li></td>
			    	    <td class="column2"><li><?php echo $row['camera'];?></li></td>
					</tr>
					
					<tr>
						<td class="column1"><li> Colors Available </li></td>
			    	    <td class="column2"><li><?php echo $row['colors'];?></li></td>
					</tr>
					<tr>
						<td class="column1"><li> Display Size & Resolution </li></td>
			    	    <td class="column2"><li> <?php echo $row['display'];?> </li></td>
					</tr>
					<tr>
						<td class="column1"><li> Operating System </li></td>
			    	    <td class="column2"><li> <?php echo $row['os'];?></li></td>
					</tr>
					<tr>
						<td class="column1"><li> Processor </li></td>
			    	    <td class="column2"><li><?php echo $row['processor'];?></li></td>
					</tr>
					<tr>
						<td class="column1"><li> RAM & ROM</li></td>
			    	    <td class="column2"><li> <?php echo $row['storage'];?> </li></td>
					</tr>
					
					<tr>
						<td class="column1"><li> Special Features </li></td>
			    	    <td class="column2"><li><?php echo $row['special_feature'];?> </li></td>
					</tr>
					<tr>
						<td class="column1"><li> Other Features</li></td>
			    	    <td class="column2"><li><?php echo $row['other_feature'];?></li></td>
					</tr>

			<?php
		}
	}
	?>
				</table>
			</div>	
			<div class="buyPhone">
				<a href="login.php?price=<?php echo $price;?> & id=<?php echo $id?>">Add To Cart</a>
			</div>	
			<div class="comparePhone">
				<a href="compare.php">Compare Phone</a>
			</div>	

			 <footer>
         <div class="icon">
           <div class="fa fa-facebook"></div>
           <div class="fa fa-twitter"></div>
            <div class="fa fa-instagram"></div>

       </div>
        Copyright Property of Aust Buddy
    </footer>

		</div>

</body>
</html>
<?php
include 'close.php';
?>
<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";
body
{
	background-color: #c3bcb7;
	font-family: algerian;
	color: white;

}
header
{	
	background-color:  #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
div.buyPhone
{
	background-color:transparent;
	height: 50px;
	width: 15%;
	margin-left: 80%;
	color: white;
    margin-top: -103%;
}
div.buyPhone a
{
	list-style: none;
    color: white;
    background: rgba(0, 5, 36, 0.9);
    padding: 10px;
    text-decoration: none;
    border-radius: 5px;
}

div.comparePhone
{
	background-color:transparent;
	height: 50px;
	width: 15%;
	margin-left: 65%;
	color: white;
    margin-top: -3.6%;
}

div.comparePhone:hover {
	animation: bounce 1s;
}

div.buyPhone:hover {
	animation: bounce 1s;
}

div.comparePhone a
{
	list-style: none;
    color: white;
    background: rgba(0, 5, 36, 0.9);
    padding: 10px;
    text-decoration: none;
    border-radius: 5px;
}

nav 
{
	border-style: none;
	margin-top: 30px;
	
}
nav ul
{
	list-style: none;
	margin-right: 20px;
	float: left;
	margin-left: 10px;
	border-style: double;
	border-bottom: #e8491d 3px solid;
	background-color:  #35424a;
	border-color: #e8491d;
	margin-top: 5%;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
nav ul li
{
	margin:15px;

}
nav ul li a
{
	text-decoration: none;
	padding: 15px;
	font-family: algerian;
	color: white;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease;


}

nav ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
nav ul li a:hover:before
{
	width:100%;
}
ul.a
{
	list-style: none;
	

}
ul.a li
{
	float: left;
	padding-right: 100px;
  

}
ul.a li a
{
	text-decoration: none;
	padding: 10px;
	font-family: algerian;
	color: white;
    border: none;
	color: #044204;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

}

ul.a li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
ul.a li a:hover:before
{
	width: 100%;
}
div.range
{
	float: right;
	margin: 10px;
	border-style: double;
	border-color: #e8491d;
	background-color: #35424a;
	position: relative;
	padding: 06px;
 	border-bottom: #e8491d 3px solid;
 	top: 10%;
 	margin-top: 6%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
div.range ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	color: rgba(248, 251, 245, 0.91);
	font-size: 100%;
}

}
div.range ul li
{
	padding: 5px;

}
div.range ul li a
{
	text-decoration: none;
	padding: 5px;
	text-align: center;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 
}

div.range ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
} 
div.range ul li a:hover:before {
	
	width: 100%
}
div.topb
{
	float: right;
	margin: 10px;
	border-style: double;
	position: relative;
	top:520px;
	left: 280px;
	right: 10px;
	padding: 45px;
	background-color: #35424a;
	border-color: #e8491d;
 	border-bottom: #e8491d 3px solid;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
div.topb ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	

}
div.topb  li
{
	padding: 3px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	color:rgb(233, 241, 225);
	font-size: 131%;
}
div.topb ul li a
{
	text-align: center;
	text-decoration: none;
	padding: 5px;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

	
}

div.topb ul li a:before
{
   content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
div.topb ul li a:hover:before
{
	
    width: 100%;
}

div.details
{
	margin-top: 30px;
}
img.pic1
{
	float: left;
	position: relative;
	left:235px;
	top: 45px;

	
}

table
{
	left:60px;
  margin-top: 5%;
  width: 700px;

}
table tr li
{
	list-style: none;

}
div.pName
{
	text-align: center;
	position: relative;
	top: 300px;
	left: 50px;
}
 .column1
{
	 text-decoration: none;
  border-style: groove;
  text-align: center;
  height: 50px;
  font-size: 15px;
   font-family: Franklin Gothic Heavy;
  top: 100%;
  padding: 10px;
  background-color:#737A73;
  -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
.column2
{
	height: 50px;
  width: 1000px;
  text-decoration: none;
  border-style: groove;
  text-align: center;
  font-size: 15px;
  padding: 5px; 
  font-family: Franklin Gothic Heavy;
  background-color:#737A73  ;
  -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
.columnEx
{
	padding: 10px;
	width: 400px;
	color: black;
	position: relative;
	top: -30px;
	left: 200px;
}

@keyframes bounce {
	0%, 20%, 60%, 100% {
		-webkit-transform: translateY(0);
		transform: translateY(0);
	}

	40% {
		-webkit-transform: translateY(-20px);
		transform: translateY(-20px);
	}

	80% {
		-webkit-transform: translateY(-10px);
		transform: translateY(-10px);
	}
}

footer
{
	border: 2px solid gray;
	background-color: #35424a;
	font-size:15px;
	text-align: center;
 	font-family: algerian;
 	color: white;
 	position: relative;
 	bottom: -50px;
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
    margin-top: 90%;
}

.icon {
    right: 10%;
    top: 20%;
}

.icon > div {
        margin: 0px, 10px;
        width: 40px;
        height: 40px;
        background: #eee;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        color: white;
        transition: all 300ms ease-in-out;
    }

div.fa-facebook {
    background: #5252b8;
}

div.fa-twitter {
    background: #00acee;
}

div.fa-instagram {
    background-color: palevioletred;
}

div.fa-facebook:hover {
    color: #5252b8;
    background-color: white;
    border: 1px solid #5252b8;
}

div.fa-twitter:hover {
    color: #00acee;
    background-color: white;
    border: 1px solid #00acee;
}

div.fa-instagram:hover {
    color: palevioletred;
    background-color: white;
    border: 1px solid #00acee;
}

</style>