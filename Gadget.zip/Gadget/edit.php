<?php
	include_once('config.php');
 
	if( isset($_GET['edit']) )
	{
		$id = $_GET['edit'];
		//$res= mysqli_query($conn,"SELECT * FROM phones WHERE id='$id'");
		//$row= mysqli_fetch_array($res);
	}
 
	if( isset($_POST['newName']) )
	{
		$newName = $_POST['newName'];
		$id  	 = $_POST['id'];
		$sql     = "UPDATE phones SET price=$newName WHERE id='$id'";
		$res 	 = mysqli_query($conn,$sql) 
                                    or die("Could not update".mysqli_error());
		echo "<meta http-equiv='refresh' content='0;url=upNdel.php'>";
	}
 
?>
<form action="edit.php" method="POST">
 <div class="middle">
 <h3>Price</h3>
<input type="text" name="newName"><br />
<input type="hidden" name="id" id="price" value="<?php echo $id ?>">
<input type="submit" value=" Update ">
</div>
<div class="shadow"></div>
</form>

<?php
include 'close.php';
?>

<style type="text/css">

body
{
	background-color:rgba(230, 233, 255, 0.93);
}

.form
{
	 background: white;
  width: 40%;
  box-shadow: 0px 0px 20px rgba(#000, .7);
  font-family: lato;
  position: relative;
  color: #333;
  border-radius: 10px;
}
 
  
 header
 {
 	 background: #FF3838;
    padding: 30px 20px;
    color: white;
    font-size: 1.2em;
    font-weight: 600;
    border-radius: 10px 10px 0 0;
 }
   
  
.middle
{
  background:white;
  border: 3px solid rgba(43, 130, 121, 0.96);
  border-radius: 6px;
  height: 257px;
  margin: 20px auto 0;
  width: 298px;
  margin-top: 15%;
  text-align:center;
  color:  rgba(43, 130, 121, 0.74);
  font-size: 24px;
}
   


input[type="text"]
{
   
  border: 1px solid #2b8279;
  border-radius: 4px;
  box-shadow: 0 1px #fff;
  box-sizing: border-box;
  color: #696969;
  height: 39px;
  margin: 30px 0 0 5px;
  padding-left: 36px;
  transition: box-shadow 0.3s;
  width: 240px;
}

input[type="text"]:focus {
  box-shadow: 0 0 4px 1px rgba(55, 166, 155, 0.3);
  outline: 0;
}

input[type="submit"]
{
  width:240px;
  height:35px;
  display:block;
  font-family:Arial, "Helvetica", sans-serif;
  font-size:16px;
  font-weight:bold;
  color:#fff;
  text-decoration:none;
  text-transform:uppercase;
  text-align:center;
  text-shadow:1px 1px 0px #37a69b;
  padding-top:6px;
  margin: 29px 0 0 29px;
  position:relative;
  cursor:pointer;
  border: none;  
  background-color: #37a69b;
  background-image: linear-gradient(top,#3db0a6,#3111);
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
  border-bottom-left-radius:5px;
  box-shadow: inset 0px 1px 0px #2ab7ec, 0px 5px 0px 0px #497a78, 0px 10px 5px #999;

}
    
.shadow {
  background: #000;
  border-radius: 12px 12px 4px 4px;
  box-shadow: 0 0 20px 10px #000;
  height: 12px;
  margin: 30px auto;
  opacity: 0.2;
  width: 270px;
}


input[type="submit"]:active {
  top:3px;
  box-shadow: inset 0px 1px 0px #2ab7ec, 0px 2px 0px 0px #31524d, 0px 5px 3px #999;
}
      
    
    

</style>