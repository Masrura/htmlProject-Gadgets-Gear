<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "gadgets");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
    $brand=$_POST['brand'];
    $model=$_POST['model'];
    $camera=$_POST['camera'];
    $battery=$_POST['battery'];
    $price=$_POST['price'];
    $display=$_POST['display'];
    $storage=$_POST['storage'];
    $color=$_POST['color'];
    $os=$_POST['os'];
  	// image file directory
  	$target = "img/".basename($image);

  	$sql = "INSERT INTO phones (model,brand,image,price,battery,camera,display,colors,storage,os) VALUES ('$model','$brand','$image','$price','$battery','$camera','$display','$storage','$color','$os')";
  	// execute query
  	$result=mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Failed to upload image";
      ?>
      <script>alert('Successful.')</script>
      <?php
  	}
    else{
  		$msg = "Failed to upload image";
      ?>
      <script>alert('unSuccessful.')</script>
      <?php
  	}
  }
  
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
<style type="text/css">
   #content{
   	width: 50%;
   	margin: 20px auto;
   	border: 1px solid #cbcbcb;
   }
   form{
   	width: 50%;
   	margin: 20px auto;
   }
   form div{
   	margin-top: 5px;
   }
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
</style>
</head>
<body>
<div id="content">
  <form method="POST" action="insert_image.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
      <p>Brand</p>
          <input type="text" name="brand">
      <p>Model</p>
          <input type="text" name="model">    
      <p>Camera</p>
          <input type="text" name="camera">
      <p>Battery</p>
          <input type="text" name="battery">
      <p>Price</p>
          <input type="text" name="price">
      <p>Display</p>
          <input type="text" name="display">
      <p>Color</p>
          <input type="text" name="color">
      <p>OS</p>
          <input type="text" name="os">
      <p>Storage</p>
          <input type="text" name="storage">

  	</div>
  	<div>

  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>
</div>
</body>
</html>