<?php
include 'config.php';

?>
<html>
	<head>
		<title>Gadgets & Gear</title>
		<link rel="stylesheet" href="css/styles.css">
		<meta charset="UTF-8">
		<meta name="keywords" content="gadgets,smartphone,review">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet"/>
		
	</head>
	
	<body>

	<div class="whole">

	<form method="POST">
		

			
		<div class="phone">
			<header>
				GADGETS AND GEAR
	        <div class="adminLogin">
                <input type="submit" name="admin" value="Admin Login">
            
			<?php 
			 if (isset($_POST["admin"]))   
			 {
                session_start();
                header("Location:admin_login.php");
			 }
			?>
            </div>
			</header>


				 <ul class="a">
					<li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=windows"> Windows </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
					
				</ul>
			
			<nav>
				<ul class="nav">
				 <?php
				$query = "SELECT * FROM brand ";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['brand_name'];

		            ?>
					     
					<li><a href="samsung.php?name=<?php echo $name; ?>"><?php echo $row['brand_name'];?> </a> </li>

				
						
			 <?php
			}
			
		}
	
		?>
					
				</ul>
			</nav>
		</div>	

		</form>
			<div class="slider">
				<figure>
					<div class="slide">
						<img src="img/slide1.jpg">
					</div>
					<div class="slide">
						<img src="img/slide2.jpg">
					</div>
					<div class="slide">
						<img src="img/slide3.jpg">
					</div>
					<div class="slide">
						<img src="img/slide4.jpg">
					</div>
					<div class="slide">
						<img src="img/slide5.jpg">
					</div>
					<div class="slide">
						<img src="img/slide6.jpg">
					</div>
					<div class="slide">
						<img src="img/slide3.jpg">
					</div>
					<div class="slide">
						<img src="img/slide4.jpg">
					</div>
					<div class="slide">
						<img src="img/slide5.jpg">
					</div>
					<div class="slide">
						<img src="img/slide6.jpg">
					</div>
				</figure>
			</div>
			<div class="range">
			<ul >
				<li>Smartphone Price Range:</li>
					<ul>
						<li><a href="samsung.php?range=0 & range2=5000">0-5000</a></li>
						<li><a href="samsung.php?range=5000 & range2=10000">5000-10000</a></li>
						<li><a href="samsung.php?range=10000 & range2=20000">10000-20000</a></li>
						<li><a href="samsung.php?range=30000 & range2=40000">30000-40000</a></li>
						<li><a href="samsung.php?range=50000 & range2=60000">50000-60000</a></li>
						<li><a href="samsung.php?range=60000 & range2=90000">60000+</a></li>
					</ul>
			</div>
			<div class="topb">
				<li>Top Brands :</li>
					<ul class="range">
						<li><a href="samsung.php?name=samsung">Samsung</a></li>
						<li><a href="samsung.php?name=walton">Walton</a></li>
						<li><a href="samsung.php?name=htc">HTC</a></li>
						<li><a href="samsung.php?name=sony">Sony</a></li>
						<li><a href="samsung.php?name=nokia">Nokia</a></li>
						<li><a href="samsung.php?name=huawei">Huawei</a></li>
					</ul>
			</div>

			</ul>
			<fieldset class="outer">
				<legend>LATEST</legend>
				<fieldset class="inner1">
					<a href="details.php?name=Samsung Galaxy S5"><img src="img/samsung_galaxy_s5.png" ><br></a>
					<a href="details.php?name=Samsung Galaxy S5"> SAMSUNG GALAXY S5</a>
				</fieldset>
				<fieldset class="inner2">
					<a href="details.php?name=Symphony XP Z1"><img src="img/sym_xp_z1.png"><br></a>
					<a href="details.php?name=Symphony XP Z1"> SYMPHONY XPLORER Z1 </a>
				</fieldset>
				<fieldset class="inner3">
					<a href="details.php?name=ASUS Zen 3"><img src="img/asus_zen3.png"><br></a>
					<a href="details.php?name=ASUS Zen 3"> ASUS ZENFONE 3</a>
				</fieldset>
				<fieldset class="inner4">
					<a href="details.php?name=Oppo R7"><img src="img/oppo_r7_plus.png"><br></a>
					<a href="details.php"> OPPO R7 Plus </a>
				</fieldset>
				<fieldset class="inner5">
					<a href="details.php?name=HTC 1 M8"><img src="img/htc_1m8.png"><br></a>
					<a href="details.php"> HTC ONE M8 </a>
				</fieldset>

			</fieldset>

			<fieldset class="outer2">
				<legend>MOST POPULAR</legend>
				<fieldset class="inner1">
					<a href="details.php?name=Samsung Galaxy J2"><img src="img/samsung_galaxy_j2.png"><br></a>
					<a href="details.php"> SAMSUNG GALAXY NOTE 6 </a>
				</fieldset>
				<fieldset class="inner2">
					<a href="details.php?name=Huawei P10"><img src="img/huawei_p10.png"><br></a>
					<a href="details.php"> HUAWEI P10 </a>
				</fieldset>
				<fieldset class="inner3">
					<a href="details.php?name=Nokia Lumia 1520"><img src="img/nokia_lumia_1520.png"><br></a>
					<a href="details.php"> NOKIA LUMIA 1520 </a>
				</fieldset>
				<fieldset class="inner4">
					<a href="details.php?name=Oppo N3"><img src="img/oppo_n3.png"><br></a>
					<a href="details.php"> OPPO N3</a>
				</fieldset>
				<fieldset class="inner5">
					<a href="details.php?name=Sony Xperia Z2"><img src="img/sony_xperia_z2.png"><br></a>
					<a href="details.php"> SONY XPERIA Z2 </a>
				</fieldset>
				
			</fieldset>
			<fieldset class="outer3">
				<fieldset class="2inner1">
					<a href="details-gadget.php?name=vr box"><img src="img/vr_box.png"><br></a>
					<a href="details.php"> VR BOX </a>
				</fieldset>
				<fieldset class="2inner2">
					<a href="details-gadget.php?name=ear_phone"><img src="img/earphone.png"><br></a>
					<a href="details.php"> EAR PHONE </a>
				</fieldset>
				<fieldset class="2inner3">
					<a href="details-gadget.php?name=smart_watch"><img src="img/smart_watch.png"><br></a>
					<a href="details.php"> GOOGLE SMART WATCH </a>
				</fieldset>
				<fieldset class="2inner4">
					<a href="details-gadget.php?name=power_bank"><img src="img/power_bank.png"><br></a>
					<a href="details.php"> POWER BANK </a>
				</fieldset>
				<fieldset class="2inner5">
					<a href="details-gadget.php?name=ear_phone2"><img src="img/earphone2.png"><br></a>
					<a href="details.php"> SAMSUNG EAR PHONE </a>
				</fieldset>
			</fieldset>
			<footer>
         <div class="icon">
           <div class="fa fa-facebook"></div>
           <div class="fa fa-twitter"></div>
            <div class="fa fa-instagram"></div>

       </div>
        <h2>Copyright Property of Aust Buddy</h2>
    </footer>
		</div>	
</body>

</html>
<?php
include 'close.php';
?>
<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";

body
div.whole
{
	background-color: #c3bcb7;
	width: 100%;
	border:1px white;
	height: 2650px;
}
header
{
	
	border: 2px white;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: white;
 	padding: 1em;
 	background-color: #35424a;
 	border-bottom: #e8491d 3px solid;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
footer
{
	border: 2px solid gray;
	background-color:  #35424a;
	font-size:10px;
	text-align:center;
 	font-family: normal;
 	line-height: 528%;
 	color: rgb(255,255,255);
 	position: relative;
 	bottom:2995px;
 	height: 109px;
 	margin-top: 3%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

nav 
{
	
	margin-top: 30px;
	
}
nav ul
{
	list-style: none;
	margin-right: 20px;
	float: left;
	margin-left: 10px;
	border-style: double;
	border-bottom: #e8491d 3px solid;
	background-color:  #35424a;
	border-color: #e8491d;
	margin-top: 5%;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
nav ul li
{
	margin:15px;

}
nav ul li a
{
	text-decoration: none;
	padding: 15px;
	font-family: algerian;
	color: white;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease;


}

nav ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
nav ul li a:hover:before
{
	width:100%;
}
ul.a
{
	list-style: none;
	

}
ul.a li
{
	float: left;
	padding-right: 100px;
  

}
ul.a li a
{
	text-decoration: none;
	padding: 10px;
	font-family: algerian;
	color: white;
    border: none;
	color: #044204;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

}

ul.a li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
ul.a li a:hover:before
{
	width: 100%;
}
fieldset.inner1,fieldset.inner2,fieldset.inner3,fieldset.inner4,fieldset.inner5,fieldset.inner6
{
	
	font-size: 12px;
	font-style: italic;
	color:#044204;
	margin-bottom: 10px;
	margin-left: 10px;
	border-style: double;
	border-color: #e8491d;
	text-align: center;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
	
}
fieldset.outer
{
	width: 200px;
	border-color: #e8491d;
	font-size: 20px
	color:blue;
	border-style: groove;
	margin-top: 14%;
	margin-left: 1%;


}
fieldset.outer2
{
	width: 200px;
	border-color: #e8491d;
	font-size: 20px
	color:blue;
	position: relative;
	left: 800px;
	bottom:1510px;
	border-style: groove;

}
fieldset.outer3
{
	width: 200px;
	border-color: #e8491d;
	font-size: 20px
	color:blue;
	position: relative;
	left: 300px;
	bottom:3000px;
	border-style: groove;
	text-align: center;
	-moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

body
{
	color: #044204;
}
legend.outer
{
	text-align: center;
	color: #044204;

}

legend.outer2
{
	color: #044204;
}

fieldset a:hover
{
	background-color: rgb(32,0,14);
}
fieldset a
{
	text-decoration: none;
	color: #044204;
}
.slider
{
	
	overflow: hidden;
	height: 400px;
	margin-top: 8%;
}
.slider figure div
{
	
	width: 10%;
	float: left;

}
div.slide
{
	height: 400px;
}
.slider figure img
{
	width: 100%;
	float: left;
}
.slider figure
{
	position: relative;
	width: 500%;
	margin: 0;
	left: 0;
	animation: 20s slidy infinite;
} 
@keyframes slidy{
	0%{
		left: 0%
	}

	10%{
		left: 0%;
	}

	12%{
		left: -100%;
	}

	22%{
		left: -100%;
	}

	24%{
		left: -200%;
	}

	34%{
		left: -200%;
	}

	36%{
		left: -300%;
	}

	46%{
		left: -300%;
	}

	48%{
		left: -400%;
	}

	58%{
		left: -400%;
	}

	60%{
		left: -300%;
	}

	70%{
		left: -300%;
	}

	72%{
		left: -200%;
	}

	82%{
		left: -200%;
	}

	84%{
		left: -100%;
	}

	94%{
		left: -100%;
	}

	96%{
		left: 0%;
	}

	100%{
		left: 0%;
	}
}
div.range
{
	float: right;
	margin: 10px;
	border-style: double;
	border-color: #e8491d;
	background-color: #35424a;
	position: relative;
	padding: 06px;
 	border-bottom: #e8491d 3px solid;
 	top: 10%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
div.range ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	color: rgba(248, 251, 245, 0.91);
	font-size: 100%;
}

}
div.range ul li
{
	padding: 5px;

}
div.range ul li a
{
	text-decoration: none;
	padding: 5px;
	text-align: center;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 
}

div.range ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
} 
div.range ul li a:hover:before {
	
	width: 100%
}
div.topb
{
	float: right;
	margin: 10px;
	border-style: double;
	position: relative;
	top:800px;
	left: 280px;
	right: 10px;
	padding: 45px;
	background-color: #35424a;
	border-color: #e8491d;
 	border-bottom: #e8491d 3px solid;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
div.topb ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	

}
div.topb  li
{
	padding: 3px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	color:rgb(233, 241, 225);
	font-size: 131%;
}
div.topb ul li a
{
	text-align: center;
	text-decoration: none;
	padding: 5px;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 

	
}

div.topb ul li a:before
{
   content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
div.topb ul li a:hover:before
{
	
    width: 100%;
}
div.about
{
	float: right;
	margin: 10px;
	border-style: double;
	position: relative;
	top:880px;
	left: 550px;
	right: 10px;
	padding: 40px;
	border-color: #e8491d;
	background-color: #35424a;
 	border-bottom: #e8491d 3px solid;
}
div.about ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	
}
div.about  li
{
	text-align: center;
	padding: 10px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	color: rgb(78,155,0);

}
div.about ul li a
{
	text-decoration: none;
	padding: 5px;
	color: white;
	
}
div.about ul li a:hover
{
	background-color:rgb(78,155,0);
}

input[type="submit"]
{
	margin-left: 81%;
	margin-top: -2%;
	background: #34d9b0;
  background-image: -webkit-linear-gradient(top, #34d9b0, #2980b9);
  background-image: -moz-linear-gradient(top, #34d9b0, #2980b9);
  background-image: -ms-linear-gradient(top, #34d9b0, #2980b9);
  background-image: -o-linear-gradient(top, #34d9b0, #2980b9);
  background-image: linear-gradient(to bottom, #34d9b0, #2980b9);
  -webkit-border-radius: 33;
  -moz-border-radius: 33;
  font-family: Arial;
  color: #ffffff;
  font-size: 18px;
  padding: 10px 14px 10px 20px;
  border: solid #20358a 3px;
  text-decoration: none;
  
}


input[type="submit"]:hover{
  background: #3cb0fd;
  background-image: -webkit-linear-gradient(top, #3cb0fd, #34d981);
  background-image: -moz-linear-gradient(top, #3cb0fd, #34d981);
  background-image: -ms-linear-gradient(top, #3cb0fd, #34d981);
  background-image: -o-linear-gradient(top, #3cb0fd, #34d981);
  background-image: linear-gradient(to bottom, #3cb0fd, #34d981);
  text-decoration: none;

}

.icon {
    right: 10%;
    top: 20%;
}

.icon > div {
        margin: 0px, 10px;
        width: 40px;
        height: 40px;
        background: #eee;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        color: white;
        transition: all 300ms ease-in-out;
    }

div.fa-facebook {
    background: #5252b8;
}

div.fa-twitter {
    background: #00acee;
}

div.fa-instagram {
    background-color: palevioletred;
}

div.fa-facebook:hover {
    color: #5252b8;
    background-color: white;
    border: 1px solid #5252b8;
}

div.fa-twitter:hover {
    color: #00acee;
    background-color: white;
    border: 1px solid #00acee;
}

div.fa-instagram:hover {
    color: palevioletred;
    background-color: white;
    border: 1px solid #00acee;
}


</style>