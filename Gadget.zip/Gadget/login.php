<?php
 include 'config.php';
 
      
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
	<title>Sign up & Log in</title>
  <header></header>
	<link rel="stylesheet" href="css/style_login.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
				
</head>
<body>
  
  <div class="title"><h1>Sign Up & Login </h1> </div>
    
    <form method="POST" action="#">
    
    <div class="container">
     
      <!-- display validation error here-->
      
  <!--$errors = array();
?>-->

    	<div class="left">
    		<div class="formBoxSignUp">
    			<p>Name</p>
    			<input type="text" name="name">
    			<p>Phone Number</p>
    			<input type="Number" name="number">
    			<p>Address</p>
    			<input type="text" name="address">
    			<p>Username</p>
    			<input type="text" name="user">
    			<p>Password</p>
    			<input type="Password" name="password">
    			<p>Confirm Password</p>
    			<input type="Password" name="conpass">
    			<input type="submit" name="signup" value="Sign Up">
    		</div>
    	</div>
    	<div class="right">
    		<div class="formBoxLogIn">
    		    
    			<p>Username</p>
    			
    			<input type="text" name="username" placeholder="Enter Username">
    			<span><i class="fa fa-user-circle" aria-hidden="true"></i></span>
    			
    			<p>Password</p>
    			<input type="Password" name="Pass" placeholder="......">
    			<span><i class="fa fa-lock" aria-hidden="true"></i></span>
    			<input type="submit" name="signin" value="Sign In">
    			
    		</div>
    	</div>
    	
    </div>
    </form>


<?php

    $p_id=$_GET['id'];
    $price=$_GET['price'];
  
   

      if(isset($_POST["signin"])) 
    {

       if(!empty($_POST['username']) && !empty($_POST['Pass']));
       {
          
           $username=$_POST['username'];
           $password=$_POST['Pass'];
          

          
           $query=mysqli_query($conn,"select * from registration where userName ='".$username."' and password = '".$password."'");
           $row=mysqli_num_rows($query);
           if($row !=0)
           {
              while ($rowno=mysqli_fetch_assoc($query)) 
              {
                $dbuser= $rowno['userName'];
                $dbpassword= $rowno['password'];
                 $c_id = $rowno['id'];
              }

              if ($username == $dbuser && $password == $dbpassword) 
              {
                echo "valid";
                ?>
                  <script>alert('Successfully Logged In')</script>
                    <?php
                    session_start();
                      $_SESSION['sess_cid']=$c_id;
                       $_SESSION['sess_pid']=$p_id;
                       $_SESSION['sess_price'] = $price;
                      header("Location:cart.php");
                    exit();
              }
              
              
           }

           else
           {

            echo "Invalid";

             ?>
                  <script>alert('unSuccessful.')</script>
                    <?php

           }

       }

      
    }
    

          if(!empty($_POST['username']) && !empty($_POST['Pass']));
       {
          
           $username=$_POST['username'];
           $password=$_POST['Pass'];
          

          
           $query=mysqli_query($conn,"select * from admin where username ='".$username."' and password = '".$password."'");
           $row=mysqli_num_rows($query);
           if($row !=0)
           {
              while ($rowno=mysqli_fetch_assoc($query)) 
              {
                $dbuser= $rowno['username'];
                $dbpassword= $rowno['password'];
                // $c_id = $rowno['id'];
              }

              if ($username == $dbuser && $password == $dbpassword) 
              {
                echo "valid";
                ?>
                  <script>alert('Successfully Logged In')</script>
                    <?php
                    session_start();
                      /*$_SESSION['sess_cid']=$c_id;
                       $_SESSION['sess_pid']=$p_id;*/
                      header("Location:admin.php");
                    exit();
              }
              
              
           }

           else 
           {

            echo "Invalid";

             ?>
                  <script>alert('unSuccessful.')</script>
                    <?php

           }

       }
    

    

   
?>



 


 <?php

    if(isset($_POST["signup"])) 
    {

       if(!empty($_POST['name']) && !empty($_POST['number']) && !empty($_POST['address']) && !empty($_POST['user']) && !empty($_POST['password']) && !empty($_POST['conpass']))
       {
           $name = $_POST['name'];
           $number=$_POST['number'];
           $password=$_POST['password'];
           $address=$_POST['address'];
           $user=$_POST['user'];
           $conpass=$_POST['conpass'];

           if ($password == $conpass) {
             # code...
           

          
           $query=mysqli_query($conn,"select * from resgistration where phoneNumber='".$number."'");
           $row=mysqli_num_rows($query);
           if($row ==0)
           {

              $sql="INSERT INTO registration (name,phoneNumber,adress,userName,password) VALUES ('$name','$number','$address','$user','$password')";
              $result=mysqli_query($conn,$sql);

              if($result)
              {
                ?>
                  <script>alert('Successful.Now logIn to continue')</script>
                    <?php
              }

              else 
              {
                echo "Failed to Register";
                 ?>
                  <script>alert('failed to Register.')</script>
                    <?php
              }
           }

           else 
           {

            echo "Invalid";

              ?>
                  <script>alert('unSuccessful.')</script>
                    <?php

           }
          }

          else{

            ?>

            <script>alert('password does not match')</script>
            <?php
          }

       }
       else 
       {

        ?>
        <script>alert('Required all field')</script>
        <?php
       }
    }




 ?>

 

    
    

</body>
</html>


<?php
include 'close.php';
?>

<style type="text/css">
body
{
  margin: 0;
  padding: 0;
  background: url(img/cov1.jpg);
  background-size: cover;
  font-family: sans-serif;
}

.title
{
     text-align: center;

}

.title h1
{
  color: rgb(243,240,243);
}

.container
{
  width: 87%;
  height: 480px;
  background: #fff;
  margin: 85px;
  border: 2px solid #fff;
  box-shadow: 0 25px 40px rgba(0,0,0,.5);
}

.container .left
{
  float: left;
  width: 50%;
  height: 480px;
  background: url(img/left1.jpg);
    background-size: cover;
  box-sizing: border-box;
}

.container .right
{
  float: right;
  width: 50%;
  height: 480px;
    background: url(img/right.jpg);
    background-size: cover;
    box-sizing: border-box;
  }

.formBoxLogIn
{
  width: 100%;
  margin: 80px;
  box-sizing: border-box;
  height: 400px;
}

.formBoxLogIn input
{
  width: 60%;
  margin-bottom: 20px;

}

.formBoxLogIn p
{
  margin: 20;
  padding: 20;
  font-weight: bold;
  color: rgb(71,32,72);
  font-size: 20px;
  
}

.formBoxLogIn input[type="text"],
.formBoxLogIn input[type="Password"]
{
  border: none;
  border-bottom: 2px solid rgb(71,32,72);
  outline: none;
  height: 20px;
  font-size: 20px;
  
  
}



.formBoxLogIn input[type="submit"]
{
  border: none;
  outline: none;
  height: 30px;
  color: white;
  cursor: pointer;
  background: rgb(71,32,71);
  font-size: 20px;
  margin-bottom: 30px;
  display: inline-block;
    vertical-align: middle;
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    transition-duration: 0.3s;
    transition-property: transform;
}

.formBoxLogIn input[type="submit"]:hover,.formBoxLogIn input[type="submit"]:focus,
.formBoxLogIn input[type="submit"]:active 
{
  background: rgb(217,0,217);
  text-align: center;
  transform: scale(1.2);
}



.formBoxSignUp
{
  width: 100%;
  padding: 10px 20px;
  box-sizing: border-box;
  height: 400px;
}

.formBoxSignUp input
{
  width: 80%;
  

}


.formBoxSignUp p
{
  margin: 20;
  padding: 20;
  font-weight: bold;
  color: rgb(9,9,137);
  font-size: 14px;
  
}

.formBoxSignUp input[type="text"],
.formBoxSignUp input[type="Password"],
.formBoxSignUp input[type="Number"]
{
  border: none;
  border-bottom: 2px solid rgb(43,43,255);
  outline: none;
  height: 20px;
  font-size: 20px;
  margin-bottom: 5px;
  
}

.formBoxSignUp input[type="submit"]
{
  border: none;
  outline: none;
  height: 20px;
  color: white;
  cursor: pointer;
  background: rgb(20,20,90);
  font-size: 16px;
   display: inline-block;
    vertical-align: middle;
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    transition-duration: 0.3s;
    transition-property: transform;
}

.formBoxSignUp input[type="submit"]:hover,.formBoxSignUp input[type="submit"]:focus,
.formBoxSignUp input[type="submit"]:active 
{
  background: rgb(153,153,243);
  text-align: center;
  transform: scale(1.2);
}


.inputBox span
{
  position: absolute;
  left: 0px;
}

p{

  text-align: center;
}

.error{

  color: red;
}

.correct{

  color: green;
}

.radioButton
{
  color: white;
  font-size: 25px;
  margin-left: 73%
}

</style>