<?php
 include 'config.php';

?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
	<title>Sign up and;</title>
	<link rel="stylesheet" href="css/style_login.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
				
</head>
<body>
    <div class="title"><h1><?php echo $_GET['id']; ?></h1> </div>
    $pid = $_GET['id'];
    <div class="container">
     <form method="POST">
      <!-- display validation error here-->
      
  <!--$errors = array();
?>-->
    	<div class="left">
    		<div class="formBoxSignUp">
    			<p>Name</p>
    			<input type="text" name="name">
    			<p>Phone Number</p>
    			<input type="Number" name="number">
    			<p>Address</p>
    			<input type="text" name="address">
    			<p>Username</p>
    			<input type="text" name="user">
    			<p>Password</p>
    			<input type="Password" name="password">
    			<p>Confirm Password</p>
    			<input type="Password" name="conpass">
    			<input type="submit" name="signup" value="Sign Up">
    		</div>
    	</div>
    	<div class="right">
    		<div class="formBoxLogIn">
    		    
    			<p>Username</p>
    			
    			<input type="text" name="username" placeholder="Enter Username">
    			<span><i class="fa fa-user-circle" aria-hidden="true"></i></span>
    			
    			<p>Password</p>
    			<input type="Password" name="Pass" placeholder="......">
    			<span><i class="fa fa-lock" aria-hidden="true"></i></span>
    			<input type="submit" name="signin" value="Sign In">
    			
    		</div>
    	</div>
    	</form>
    </div>


<?php

    if(isset($_POST["signin"])) 
    {

       if(!empty($_POST['username']) && !empty($_POST['Pass']));
       {
          
           $username=$_POST['username'];
           $password=$_POST['Pass'];
          

           $conn=new mysqli('localhost' ,'root' ,'') or die(mysqli_error());
           $db=mysqli_select_db($conn,'gadgets') or die("DB Error");
           $query=mysqli_query($conn,"select * from registration where userName ='".$username."' and password = '".$password."'");
           $row=mysqli_num_rows($query);
           if($row !=0)
           {
           
              while ($rowno=mysqli_fetch_assoc($query)) 
              {
                $dbuser= $rowno['userName'];
                $dbpassword= $rowno['password'];
                $cid = $rowno['id'];
              }

              if ($username == $dbuser && $password == $dbpassword) 
              {
                echo "valid";
                ?>
                  <script>alert('Successful')</script>
                    <?php
                    
                   
                     //$id = $_GET['id'];
                     
                       
                       session_start();
                      $_SESSION['sess_cid']=$cid;
                      header("Location:cart.php");

              }
              
             
           }

           else 
           {

            echo "Invalid";

             ?>
                  <script>alert('unSuccessful.')</script>
                    <?php

           }

       }

      
    }
?>



 


 <?php

    if(isset($_POST["signup"])) 
    {

       if(!empty($_POST['name']) && !empty($_POST['number']) && !empty($_POST['address']) && !empty($_POST['user']) && !empty($_POST['password']) && !empty($_POST['conpass']))
       {
           $name = $_POST['name'];
           $number=$_POST['number'];
           $password=$_POST['password'];
           $address=$_POST['address'];
           $user=$_POST['user'];
           $conpass=$_POST['conpass'];

           if ($password == $conpass) {
             # code...
           

           $conn=new mysqli('localhost' ,'root' ,'') or die(mysqli_error());
           $db=mysqli_select_db($conn,'gadgets') or die("DB Error");
         

              $sql="INSERT INTO registration (name,phoneNumber,adress,userName,password) VALUES ('$name','$number','$address','$user','$password')";
              $result=mysqli_query($conn,$sql);

              if($result)
              {
                ?>
                  <script>alert('Successful.Now logIn to continue')</script>
                    <?php
              }

              else 
              {
                echo "Failed to Register";
                 ?>
                  <script>alert('failed to Register.')</script>
                    <?php
              }
           

           
          }

          else{

            ?>

            <script>alert('password does not match')</script>
            <?php
          }

       }
       else 
       {

        ?>
        <script>alert('Required all field')</script>
        <?php
       }
    }




 ?>

 

    
    

</body>
</html>


<?php
include 'close.php';
?>

<style type="text/css">
body
{
  margin: 0;
  padding: 0;
  background: url(cov1.jpg);
  background-size: cover;
  font-family: sans-serif;
}

.title
{
     text-align: center;

}

.title h1
{
  color: rgb(243,240,243);
}

.container
{
  width: 87%;
  height: 480px;
  background: #fff;
  margin: 85px;
  border: 2px solid #fff;
  box-shadow: 0 25px 40px rgba(0,0,0,.5);
}

.container .left
{
  float: left;
  width: 50%;
  height: 480px;
  background: url(left1.jpg);
    background-size: cover;
  box-sizing: border-box;
}

.container .right
{
  float: right;
  width: 50%;
  height: 480px;
    background: url(right.jpg);
    background-size: cover;
    box-sizing: border-box;
  }

.formBoxLogIn
{
  width: 100%;
  margin: 80px;
  box-sizing: border-box;
  height: 400px;
}

.formBoxLogIn input
{
  width: 60%;
  margin-bottom: 20px;

}

.formBoxLogIn p
{
  margin: 20;
  padding: 20;
  font-weight: bold;
  color: rgb(71,32,72);
  font-size: 20px;
  
}

.formBoxLogIn input[type="text"],
.formBoxLogIn input[type="Password"]
{
  border: none;
  border-bottom: 2px solid rgb(71,32,72);
  outline: none;
  height: 20px;
  font-size: 20px;
  
  
}



.formBoxLogIn input[type="submit"]
{
  border: none;
  outline: none;
  height: 30px;
  color: white;
  cursor: pointer;
  background: rgb(71,32,71);
  font-size: 20px;
  margin-bottom: 30px;
}

.formBoxLogIn input[type="submit"]:hover
{
  background: rgb(217,0,217);
  text-align: center;

}



.formBoxSignUp
{
  width: 100%;
  padding: 10px 20px;
  box-sizing: border-box;
  height: 400px;
}

.formBoxSignUp input
{
  width: 80%;
  

}


.formBoxSignUp p
{
  margin: 20;
  padding: 20;
  font-weight: bold;
  color: rgb(9,9,137);
  font-size: 14px;
  
}

.formBoxSignUp input[type="text"],
.formBoxSignUp input[type="Password"],
.formBoxSignUp input[type="Number"]
{
  border: none;
  border-bottom: 2px solid rgb(43,43,255);
  outline: none;
  height: 20px;
  font-size: 20px;
  margin-bottom: 5px;
  
}

.formBoxSignUp input[type="submit"]
{
  border: none;
  outline: none;
  height: 20px;
  color: white;
  cursor: pointer;
  background: rgb(20,20,90);
  font-size: 16px;
}

.formBoxSignUp input[type="submit"]:hover
{
  background: rgb(153,153,243);
  text-align: center;

}


.inputBox span
{
  position: absolute;
  left: 0px;
}

p{

  text-align: center;
}

.error{

  color: red;
}

.correct{

  color: green;
}

</style>