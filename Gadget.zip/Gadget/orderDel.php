<?php

	$link = mysqli_connect("localhost", "root", "", "gadgets");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt update query execution
if (isset($_GET['del'])) 
{
	$id = $_GET['del'];
	$sql = "UPDATE ordertable SET delivery_status='delivered' where order_id = $id";
if(mysqli_query($link, $sql)){
    //echo "Records were updated successfully.";
    echo "<meta http-equiv='refresh' content='0;url=ordertable.php'>";
} 
else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

 
// Close connection
mysqli_close($link);
?>