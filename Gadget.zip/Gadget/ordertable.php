<?php
include 'config.php';

session_start();

$res = mysqli_query($conn,"SELECT * FROM ordertable");
           	           
?>

<!DOCTYPE html>
<html>
<head>
	<title> Details</title>
	<link rel="stylesheet" href="css/style_details.css">
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>-->
	<meta charset="UTF-8">
	<meta name="keywords" content="gadgets,smartphone,review">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

</head>
<body>
<div class="whole">
		<header>order Cart</header>

			<div class="orderList">
	<table id="orderCart">
	<th>Order Id</th>
	<th>Cart Id</th>
	<th>Product Id</th>
	<th>Customer Id</th>
	<th>Amount</th>
	<th>Delivery Status</th>
	<th>Delivery</th>

<?php
	while( $row = mysqli_fetch_array($res) )
	{
	?>
<tr>
	<td><?php echo $row['order_id'];?></td>
	<td><?php echo $row['cart_id'];?></td>
	<td><?php echo $row['product_id'];?></td>
	<td><?php echo $row['customer_id'];?></td>
	<td><?php echo $row['amount'];?></td>
	<td><?php echo $row['delivery_status'];?></td>
	<td><a href="orderDel.php?del=<?php echo $row['order_id']; ?>">delivery</a></td>
</tr>
<?php	  //echo "<li>$row[brand_id]. <li>$row[brand_name]</li> 
                //<li><a href='delete.php?del=$row[brand_id]'>delete</a></li><br/>";
	}
?>

</table>
</div>
			</div>


			</body>
			</html>

<?php
include 'close.php';
?>

<style type="text/css">
body
{
	background-color: white;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: black;

}
header
{
	
	border: 2px solid gray;
	background-color: #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;


}


div.cartList table tr td
{
	list-style: none;
    text-align: center;
    border: groove;
    left: 10%;
}

table
{
	left: 300px;
	top: 100px;
}

.pay
{
	margin-left: 91%;
    margin-top: -2%;
}

th {
  color: #000000;
  background-color: #d82525;
  height: 35px;
  font-style: italic;


}

td {
  text-align: center;
  column-width: 50px;
  color: #000000;
  font-style: italic;
  font-size: 14px;
 
}

#orderCart {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;
    margin-top: -3%;
}

#orderCart td,#orderCart th {
    border: 1px solid #ddd;
    padding: 8px;
    height: 41px;
  }

  #orderCart tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  #orderCart tr:hover {
    background-color: #ddd;
  }

  #orderCart th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
  }


</style>