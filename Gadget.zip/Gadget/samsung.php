
<?php
include 'config.php';

?>
<html>
	<head>
		<title>Samsung</title>
		<link rel="stylesheet" href="css/stysle_samsung.css">
		<meta charset="UTF-8">
		<meta name="keywords" content="gadgets,smartphone,review">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
	</head>
	<body>
		<div class="Samsung">
		<header>
				<?php 
				if(isset($_GET['range']))
					{
						echo $_GET['range']; echo "-";echo $_GET['range2'];
					} 
				else if(isset($_GET['name']))
					{
						echo $_GET['name'];
					}
				else if(isset($_GET['catagory']))
					{
						echo $_GET['catagory'];
					}			
			    ?>
		</header>


		<table class="ph">

		    <tr>
		    	<td id="bar1"><li><a href="samsung.php?name=nokia"> NOKIA </a></li></td>
		    	<td id="bar1"><li><a href="samsung.php?name=samsung"> SAMSUNG </a></li></td>
		    	<td id="bar1"><li><a href="samsung.php?name=sony"> SONY </a></li></td>
		    	<td id="bar1"><li><a href="samsung.php?name=huawei"> HUAWEI </a></li> </td>
		    	<td id="bar1"><li><a href="samsung.php?name=xiaomi"> XIAOMI </a></li> </li> </td>

		    	
		    	
		    </tr>

		    <tr>
		    	<td id="bar1"> <li><a href="samsung.php?name=walton"> WALTON </a> </li></td>
		    	<td id="bar1"> <li><a href="samsung.php?name=htc"> HTC </a> </li></td>
		    	<td id="bar1"><li><a href="samsung.php?name=oppo"> OPPO </a> </li></td>
		    	<td id="bar1"> <li><a href="samsung.php?name=symphony"> SYMPHONY </a></li></td>
		    	<td id="bar1"> <li><a href="samsung.php?name=asus"> ASUS </a></li></td>
		    		
		    </tr>
		    </table>
		    <table>
		    <tr class="link">
		    <?php
		    if(isset($_GET['name']))
		    {

				$query = "SELECT * FROM phones where brand = '" . $_GET['name'] . "' order by price limit 3";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td>
						<a href="details.php?name=<?php echo $name; ?>"> <img src="<?php echo $row['image'];?>"><br><p><?php echo $name;?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>
		<tr class="link">
		    <?php
		    if(isset($_GET['name']))
		    {
				$query = "SELECT * FROM phones where brand = '" . $_GET['name'] . "'order by price desc limit 3";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td><a href="details.php?name=<?php echo $name; ?>"><img src="<?php echo $row['image'];?>"><br><p><?php echo $row['model'];?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>
		<tr class="link">
		 <?php
		    if(isset($_GET['range']))
		    {

				$query = "SELECT * FROM phones where price between '" . $_GET['range'] . "' and '" . $_GET['range2'] . "'order by price limit 5";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td>
						<a href="details.php?name=<?php echo $name; ?>"> <img src="<?php echo $row['image'];?>"><br><p><?php echo $name;?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>
		<tr class="link">
		 <?php
		    if(isset($_GET['range']))
		    {

				$query = "SELECT * FROM phones where price between '" . $_GET['range'] . "' and '" . $_GET['range2'] . "'order by price desc limit 5";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td>
						<a href="details.php?name=<?php echo $name; ?>"> <img src="<?php echo $row['image'];?>"><br><p><?php echo $name;?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>
		

		 <!--<tr class="link">
                   <td><a href="details.php"><img src="img/samsung_galaxy_s4.png"><br><p>Samsung Galaxy S4</p><br>Price: 20,000</td></a>
                   <td><a href="details.php"><img src="img/samsung_galaxy_s6.png"><br><p>Samsung Galaxy S6</p><br>Price: 70,000</td></a>
                   <td><a href="details.php"><img src="img/samsung_galaxy_j1.png"><br><p>Samsung Galaxy J1</p><br>Price: 9,000</td></a>
                   <td><a href="details.php"><img src="img/samsung_galaxy_j2.png"><br><p>Samsung Galaxy J2</p><br>Price: 10,000</td></a>
                   <td><a href="details.php"><img src="img/samsung_galaxy_s5.png"><br><p>Samsung Galaxy S5</p><br>Price: 60,000</td></a>
		-->

		
		 <tr class="link">
		    <?php
		    if(isset($_GET['catagory']))
		    {

				$query = "SELECT * FROM phones where catagory = '" . $_GET['catagory'] . "' order by price limit 3";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td>
						<a href="details.php?name=<?php echo $name; ?>"> <img src="<?php echo $row['image'];?>"><br><p><?php echo $name;?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>
		<tr class="link">
		    <?php
		    if(isset($_GET['catagory']))
		    {
				$query = "SELECT * FROM phones where catagory = '" . $_GET['catagory'] . "'order by price desc limit 3";
				$players_query_result = mysqli_query($conn,$query) or die(mysql_error());

				if(mysqli_num_rows($players_query_result) > 0)
				{
					while ($row = mysqli_fetch_array($players_query_result))
					{
						$name=$row['model'];

		            ?>
					     
					    
						<td><a href="details.php?name=<?php echo $name; ?>"><img src="<?php echo $row['image'];?>"><br><p><?php echo $row['model'];?></p><br><?php echo $row['price'];?></td></a>

				
						
			 <?php
			}
		}
	}
		?>
		</tr>

		</table> 


			<section id ="menu">
			
				<div class="range">
				<li><h2>Smartphone Price Range</h2></li>
					<ul>
						<li><a href="samsung.php?range=0 & range2=5000">0-5000</a></li>
						<li><a href="samsung.php?range=5000 & range2=10000">5000-10000</a></li>
						<li><a href="samsung.php?range=10000 & range2=20000">10000-20000</a></li>
						<li><a href="samsung.php?range=30000 & range2=40000">30000-40000</a></li>
						<li><a href="samsung.php?range=50000 & range2=60000">50000-60000</a></li>
						<li><a href="samsung.php?range=60000 & range2=90000">60000+</a></li>
					</ul>
					
				</div>
				<div class="topb">
					<li><h2>Top brands</h2></li>
					<ul>
							<li><a href="layout_1.php"> HOME </a> </li>
					<li><a href="samsung.php?catagory=android"> SMARTPHONE </a></li>
					<li><a href="samsung.php?catagory=android"> ANDROID </a></li>
					<li><a href="samsung.php?catagory=tab"> TAB</a></li>
					<li><a href="samsung.php?catagory=feature"> FEATURE PHONE</a></li>
					<li><a href="aboutUs.php"> ABOUT US </a></li>
					</ul>
				</div>
		
			</section>	

			<!--<footer>
				Copyright Prpperty of Gadgets and Gear
		    </footer>-->
		    <footer>
         <div class="icon">
           <div class="fa fa-facebook"></div>
           <div class="fa fa-twitter"></div>
            <div class="fa fa-instagram"></div>

       </div>
        Copyright Property of Aust Buddy
    </footer>
			
		</div>

		
	</body>
<?php
include 'close.php';

?>

<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";


header
{
	
	border: 2px white;
	background-color: #35424a;
	font-size:70px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(255,255,255);
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

div.Samsung
{
	margin: 10px 30px 0px 30px;
	background-color: #c3bcb7;
	height: 1400px;
	width: 96%;
	color: white;
}

#bar1
{
	text-align: center;
	width: 2px;
	font-family: normal;
	background-color:rgba(42, 70, 254, 0.85);
	padding: 10px;
	text-decoration: none;
	position: relative;
	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}

#bar1 li a
{
	color: white;
}

footer
{
	border: 2px solid gray;
    background-color: #35424a;
    font-size: 15px;
    text-align: center;
    font-family: algerian;
    color: white;
    position: relative;
    bottom: -50px;
    padding: 1em;
    height: 82px;
    margin-top: 31%;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}

.icon {
    right: 10%;
    top: 20%;
}

.icon > div {
        margin: 0px, 10px;
        width: 40px;
        height: 40px;
        background: #eee;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        color: white;
        transition: all 300ms ease-in-out;
    }

div.fa-facebook {
    background: #5252b8;
}

div.fa-twitter {
    background: #00acee;
}

div.fa-instagram {
    background-color: palevioletred;
}

div.fa-facebook:hover {
    color: #5252b8;
    background-color: white;
    border: 1px solid #5252b8;
}

div.fa-twitter:hover {
    color: #00acee;
    background-color: white;
    border: 1px solid #00acee;
}

div.fa-instagram:hover {
    color: palevioletred;
    background-color: white;
    border: 1px solid #00acee;
}

#menu .range
{
	float: left;
    width: 30%;
    margin: 30px;
    padding: 3px;
    border-style: double;
    position: relative;
    border-color: #e8491d;
    background-color: #35424a;
    border-bottom: #e8491d 3px solid;
    margin-left: 10%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}
div.range ul
{
	list-style: none;
	padding: 20px;
	font-family: algerian;
	color: rgba(248, 251, 245, 0.91);
	font-size: 100%;
}

div.range li
{
	color: white;
}

}
div.range ul li
{
	padding: 5px;
}
div.range ul li a
{
	text-decoration: none;
	text-align: center;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease; 
}

div.range ul li a:before {
	content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
} 
div.range ul li a:hover:before {
	
	width: 100%
}

#menu .topb
{
	float: left;
    width: 30%;
    margin: 35px;
    border-style: double;
    position: relative;
    border-color: #e8491d;
    background-color: #35424a;
    border-bottom: #e8491d 3px solid;
    margin-left: 20%;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;
}
div.topb ul
{
	list-style: none;
    padding: 8px;
    font-family: algerian;
}
div.topb  li
{
	padding: -2px;
	list-style: none;
	text-decoration: none;
	font-family: algerian;
	color:rgb(233, 241, 225);
	font-size: 131%;
}
div.topb ul li a
{
	text-decoration: none;
	text-align: center;
	border: none;
	color: #f2f2f2;
	padding: 10px;
	font-size: 18px;
	border-radius: 5px;
	position: relative;
	box-sizing: border-box;
	transition: all 500ms ease;  	
}

div.topb ul li a:before
{
   content:'';
	position: absolute;
	top: 0px;
	left: 0px;
	width: 0px;
	height: 42px;
	background: rgba(255,255,255,0.3);
	border-radius: 5px;
	transition: all 2s ease;
}
div.topb ul li a:hover:before
{	
    width: 100%;
}


tr.link a {
	color: blue;
	display: inline-block;
    vertical-align: middle;
    transform: translateZ(0);
    box-shadow: 0 0 1px rgba(0, 0, 0, 0);
    backface-visibility: hidden;
    -moz-osx-font-smoothing: grayscale;
    transition-duration: 0.3s;
    transition-property: transform;
    text-decoration: none;
}

tr.link a:hover,
tr.link a:focus,
tr.link a:active {
    transform: scale(1.4);
}

</style>