<?php
include 'config.php';

session_start();

$customer = $_SESSION['sess_cid'];
$res = mysqli_query($conn,"select * from cart where c_id ='".$customer."'");
?>

<!DOCTYPE html>
<html>
<head>
	<title> Details</title>
	<link rel="stylesheet" href="css/style_details.css">
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>-->
	<meta charset="UTF-8">
	<meta name="keywords" content="gadgets,smartphone,review">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

</head>
<body>
<div class="whole">
		<header>See My Cart</header>
	<div class="cartList">
	<table id="mycart">
	<th>customer id</th>
	<th>product id</th>
	<th>quantity</th>
	<th>address</th>
	<th>price</th>
	<th>delete</th>

<?php
	while( $row = mysqli_fetch_array($res) )
	{
	?>

<tr>
    
	<td><?php echo $row['c_id'];?></td>
	<td><?php echo $row['p_id'];?></td>
	<td><?php echo $row['quantity'];?></td>
	<td><?php echo $row['address'];?></td>
	<td><?php echo $row['price']; ?></td>
	<td><a href="delCart.php?delete=<?php echo $row['p_id']; ?>">delete</a></td>
	<!--<td><a href="delete.php?del=<?php echo $row['id']; ?>">delete</a></td>-->
</tr>
<?php	  //echo "<li>$row[brand_id]. <li>$row[brand_name]</li> 
                //<li><a href='delete.php?del=$row[brand_id]'>delete</a></li><br/>";
	}

    $sum = 0;
	$query=mysqli_query($conn,"select * from cart where c_id ='".$customer."' ");
   $row=mysqli_num_rows($query);

   if($row !=0)
           {
              while ($row=mysqli_fetch_assoc($query)) 
              {
                $pri= $row['price'];
                $quan= $row['quantity'];
                 
                $total = $pri*$quan;
                $sum = $sum + $total;

                $cart = $row['id'];
                $pro = $row['p_id'];
                $cus = $row['c_id'];
                
                //$del = $del1;

                if (isset($_POST["payment"])) 
            {
  	       $conn=new mysqli('localhost' ,'root' ,'') or die(mysqli_error());
           $db=mysqli_select_db($conn,'gadgets') or die("DB Error");

		      $sql="INSERT INTO ordertable (cart_id,product_id,customer_id,amount) VALUES ('$cart','$pro','$cus','$pri')";
              $result=mysqli_query($conn,$sql);

              if($result)
              {
                ?>
                  <script>alert('Added to ordertable')</script>
                    <?php

                     /*$_SESSION['sess_pid'] = $sql1;
                   $_SESSION['sess_cid'] = $sql2;
                    $_SESSION['sess_price'] = $pro_price;*/
                   header("Location:layout_1.php");
                   exit();
              }

              else 
              {
                 ?>
                  <script>alert('unsuccessfull')</script>
                    <?php
              }
         }

              }

              

             

             

          }


?>

</table>
</div>
<form method="POST">
	<div class="pay">
	<input type="submit" name="payment" value="done">

	
</div>

<?php
  
?>
</form>
<div class="sumPrint">
              	<h3>Your total amount is : <?php echo $sum;?> </h3>
              	<h3>You have to pay your bill when it will be delivered to your given address</h3>
              	
              </div>
</div>
<?php 
  
  
?>


			</body>
			</html>


<?php
include 'close.php';
?>

<style type="text/css">
@import "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css";
body
{
	background-color: white;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: black;

}
header
{
	
	border: 2px solid gray;
	background-color: #35424a;
	font-size:30px;
	text-align:center;
 	font-family: algerian;
 	color: rgb(182,220,204);
 	padding: 1em;
 	 -moz-box-shadow: inset 0 0 100px #000000;
    -webkit-box-shadow: inset 0 0 100px #000000;
    box-shadow: inset 0 0 100px #000000;

}

	
div.cartList table tr td
{
	list-style: none;
    text-align: center;
    border: groove;
    left: 10%;
}

table
{
	left: 300px;
	top: 100px;
}

.pay
{
	margin-left: 91%;
    margin-top: -2%;
    
}
@keyframes bounce {
	0%, 20%, 60%, 100% {
		-webkit-transform: translateY(0);
		transform: translateY(0);
	}

	40% {
		-webkit-transform: translateY(-20px);
		transform: translateY(-20px);
	}

	80% {
		-webkit-transform: translateY(-10px);
		transform: translateY(-10px);
	}
}
input[type="submit"]:hover {
	animation: bounce 1s;
}

input[type="submit"]
{
	background-color:#4CAF50;
	height: 50px;
	width: 100px;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	color: white;
	font-size: 20px;
}


th {
  color: #000000;
  background-color: #d82525;
  height: 35px;
  font-style: italic;


}

td {
  text-align: center;
  column-width: 50px;
  color: #000000;
  font-style: italic;
  font-size: 14px;
 
}

#mycart {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;
    margin-top: -3%;
}

#mycart td, #mycart th {
    border: 1px solid #ddd;
    padding: 8px;
    height: 41px;
  }

  #mycart tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  #mycart tr:hover {
    background-color: #ddd;
  }

  #mycart th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
  }

 .sumPrint
 {
        margin-top: 9%;
    margin-left: 38%;
 }
</style>