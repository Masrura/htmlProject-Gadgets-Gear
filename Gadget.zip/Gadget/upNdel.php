<?php
	include_once('config.php');
 
	
 $res = mysqli_query($conn,"SELECT * FROM phones");
 
 
?>
<html>
<head>

	<meta charset="UTF-8">
		<meta name="keywords" content="gadgets,smartphone,review">
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
<body>

<div id="mainbody">
<br />
 
<div class="productList">
	<table class="table" id="customers">

		<tbody>

  <thead>
    <tr>
      <th>Model</th>
      
      <th>Price</th>
      <th id="details">Storage</th>
      <th>Camera</th>
      <th class="display">Display</th>

      <th>Delete</th>
      <th>Edit</th>
    </tr>
</thead>


<?php
	while( $row = mysqli_fetch_array($res) )
	{
	?>
<tr>
	<td><?php echo $row['model'];?></td>
	
	<td><?php echo $row['price'];?></td>
	<td><?php echo $row['storage'];?></td>
  <td><?php echo $row['camera'];?></td>
  <td><?php echo $row['display'];?></td>
	<td><a href="delete.php?del=<?php echo $row['id']; ?>">delete</a></td>
  <td><a href="edit.php?edit=<?php echo $row['id']; ?>">edit</a></td>
 
</tr>
<?php	  //echo "<li>$row[brand_id]. <li>$row[brand_name]</li> 
          //<li><a href='delete.php?del=$row[brand_id]'>delete</a></li><br/>";
	}
?>

</tbody>

</table>
</div>

</div>
</body>
</html>

<style type="text/css">

#mainbody
{
	width: 1000px;
	margin-left: 180px;
	margin-top: 30px;

}

th {
  color: #000000;
  background-color: #d82525;
  height: 35px;
  font-style: italic;


}

td {
  text-align: center;
  column-width: 50px;
  color: #000000;
  font-style: italic;
  font-size: 14px;
 
}

#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

  #customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
  }

  #customers tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  #customers tr:hover {
    background-color: #ddd;
  }

  #customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
  }


#name
{
  display: inline-block;
}

#enter
{
  float: right;
  margin-right:50%;
  width: 80px;
  height: 32px;
}

#del
{
  height:30px;
}


input[type="text"]
 {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
}

input[type="text"]:focus
{
  border-bottom: 2px solid #16a085;
  color: #16a085;
  transition: 0.2s ease;
}
div.display
{
  width: 100px;
}

</style>